import React, { useEffect, useState } from "react";
import SplashScreen from "./SplashScreen";
import logo from "./assets/logo-gold.png";
import aboutImage from "./assets/about.jpg";
import technologyImage from "./assets/technology-impact.jpg";
import miluImage from "./assets/milu-ai.webp";
import ecosystemImage from "./assets/ecosystem.jpg";
import careersImage from "./assets/careers.jpg";
import teamDroneLab from "./assets/team-drone-lab.jpg";
import teamFieldDeployment from "./assets/team-field-deployment.jpg";
import surveillanceRecon from "./assets/solutions/surveillance-recon.jpg";
import earthObservationImage from "./assets/solutions/earth-observation.webp";
import precisionAgricultureImage from "./assets/solutions/precision-agriculture.jpg";
import infrastructureMonitoringImage from "./assets/solutions/infrastructure-monitoring.webp";
import disasterResponseImage from "./assets/solutions/disaster-response.webp";
import autonomousLogisticsImage from "./assets/solutions/autonomous-logistics.jpg";
import { useTheme } from "./utils/theme";
import Hero from "./Hero";
import Solutions from "./Solutions";

import harshitDixit from "./assets/team/harshit-dixit.jpg";
import aliRaza from "./assets/team/ali-raza.jpg";
import satyamJha from "./assets/team/satyam-jha.jpg";
import awadheshPathak from "./assets/team/awadhesh-pathak.jpg";
import ishanShrivastava from "./assets/team/ishan-srivastava.jpg";
import riteshKumar from "./assets/team/ritesh-kumar.jpg";
import sumitShukla from "./assets/team/sumit-shukla.jpg";
import shwetaSharma from "./assets/team/shweta-sharma.jpg";
import adityaSrivastava from "./assets/team/aditya-srivastava.jpg";
import abhishekDixit from "./assets/team/abhishek-dixit.jpg";
import prakharGupta from "./assets/team/prakhar-gupta.jpg";
import paramjeetBind from "./assets/team/paramjeet-bind.jpg";
import mayankAgarwal from "./assets/team/mayank-agarwal.jpg";
import shubhamChaudhary from "./assets/team/shubham-chaudhary.jpg";
import aviralSingh from "./assets/team/aviral-singh.jpg";

type Item = {
  title: string;
  text: string;
  icon?: string;
  image?: string;
  slug?: string;
};
const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
const solutionPath = (s: string) => `/solutions/${slug(s)}`;
const servicePath = (s: string) => `/services/${slug(s)}`;
function navigate(path: string) {
  if (path === location.pathname) return;
  history.pushState({}, "", path);
  window.dispatchEvent(new PopStateEvent("popstate"));
  window.scrollTo(0, 0);
}
function go(id: string) {
  document
    .getElementById(id)
    ?.scrollIntoView({ behavior: "smooth", block: "start" });
}

const solutions: Item[] = [
  {
    title: "Surveillance & Reconnaissance",
    text: "Persistent aerial intelligence for complex environments.",
    image: surveillanceRecon,
  },
  {
    title: "Earth Observation",
    text: "Insight from aerial, spatial and remote-sensing data.",
    image: earthObservationImage,
  },
  {
    title: "Precision Agriculture",
    text: "Field intelligence for more precise agricultural decisions.",
    image: precisionAgricultureImage,
  },
  {
    title: "Infrastructure Monitoring",
    text: "Safer, smarter inspection across critical assets.",
    image: infrastructureMonitoringImage,
  },
  {
    title: "Disaster Response",
    text: "Situational awareness when every second counts.",
    image: disasterResponseImage,
  },
  {
    title: "Autonomous Logistics",
    text: "Move critical payloads beyond conventional routes.",
    image: autonomousLogisticsImage,
  },
];

const sectorData: Item[] = [
  {
    title: "Agriculture & Rural Systems",
    text: "Farming, rural infrastructure, field intelligence and agricultural operations.",
    icon: "leaf",
  },
  {
    title: "Infrastructure & Industrial",
    text: "Construction, industrial assets, inspection, surveying and monitoring.",
    icon: "factory",
  },
  {
    title: "Security & Public Safety",
    text: "Surveillance, reconnaissance, emergency awareness and public-safety operations.",
    icon: "shield",
  },
  {
    title: "Logistics & Delivery",
    text: "Medical, agricultural, emergency and remote delivery operations.",
    icon: "truck",
  },
  {
    title: "Geospatial & Visual Intelligence",
    text: "Surveying, mapping, imaging and geospatial information.",
    icon: "globe",
  },
  {
    title: "Energy & Utilities",
    text: "Power, solar, utilities and associated infrastructure.",
    icon: "energy",
  },
];

// ─────────────────────────────────────────────────────────────────────────
// SERVICES — rebuilt around 4 core offerings (Sale, Repair & Maintenance,
// Rental, Training). Replaces the old 8-category service directory.
//
// ⚠ TWO FACTS ARE STILL UNCONFIRMED — search "TODO CONFIRM" below:
//   1) Drone Sale — does OJAS manufacture, resell third-party brands, or both?
//   2) Drone Training — is OJAS a DGCA-certified RPTO (Remote Pilot Training
//      Organisation)? Do not publish a certification claim until confirmed.
// Image paths are placeholders — drop real files into
// src/assets/services/<slug>/... and the imports at the top of this file.
// ─────────────────────────────────────────────────────────────────────────
type ServiceOffering = {
  title: string;
  description: string;
  visual: string;
  specs?: { label: string; value: string }[];
};
type ServiceStep = { step: string; title: string; description: string };
type ServiceFAQ = { q: string; a: string };
type ServiceContent = {
  slug: string;
  icon: string;
  eyebrow: string;
  title: string;
  tagline: string;
  ctaPrimary: string;
  ctaSecondary: string;
  includesHeading: string;
  includesIntro: string;
  includes: ServiceOffering[];
  processHeading: string;
  process: ServiceStep[];
  whyHeading: string;
  why: { title: string; description: string }[];
  pricingHeading: string;
  pricingNote: string;
  pricingCta: string;
  faq: ServiceFAQ[];
  ctaTitle: string;
  ctaSubtitle: string;
};
const services: ServiceContent[] = [
  {
    slug: "drone-sale",
    icon: "drone",
    eyebrow: "Drone Sale",
    title: "The right drone, built for the work it needs to do.",
    tagline:
      "Agriculture, mapping, surveillance and custom platforms — supplied, configured and registered, ready for the field.",
    ctaPrimary: "Request a Quote",
    ctaSecondary: "Book a Demo Flight",
    includesHeading: "Choose by category",
    includesIntro:
      "Every platform is matched to its job — payload, endurance and sensors selected for the environment it will operate in.",
    includes: [
      {
        title: "Agriculture Spraying Drones",
        visual: "leaf",
        description:
          "High-payload spraying platforms for precision input application across crop fields.",
        specs: [
          { label: "Payload", value: "10 – 40 L tank" },
          { label: "Flight Time", value: "18 – 25 min / cycle" },
          { label: "Range", value: "Up to 2 km (VLOS)" },
          { label: "Sensor", value: "RTK-GPS + terrain-follow radar" },
        ],
      },
      {
        title: "Mapping & Survey Drones",
        visual: "map",
        description:
          "Fixed-wing and multirotor platforms for orthomosaics, topographic survey and land digitisation.",
        specs: [
          { label: "Payload", value: "Up to 1.5 kg camera / LiDAR" },
          { label: "Flight Time", value: "35 – 55 min" },
          { label: "Range", value: "Up to 5 km" },
          { label: "Sensor", value: "RGB / multispectral / LiDAR" },
        ],
      },
      {
        title: "Surveillance & Inspection Drones",
        visual: "eye",
        description:
          "Stabilised, low-light-capable platforms for perimeter monitoring and infrastructure inspection.",
        specs: [
          { label: "Payload", value: "Gimbal camera + thermal (optional)" },
          { label: "Flight Time", value: "28 – 40 min" },
          { label: "Range", value: "Up to 7 km" },
          { label: "Sensor", value: "EO/IR gimbal, zoom optics" },
        ],
      },
      {
        // TODO CONFIRM: manufacture vs. configure third-party airframes — adjust once confirmed.
        title: "Custom & Enterprise-Built Drones",
        visual: "cpu",
        description:
          "Purpose-built configurations for non-standard payloads, mission profiles or enterprise fleets.",
        specs: [
          { label: "Payload", value: "Mission-specific" },
          { label: "Flight Time", value: "Mission-specific" },
          { label: "Range", value: "Mission-specific" },
          { label: "Sensor", value: "Configurable" },
        ],
      },
    ],
    processHeading: "From enquiry to delivery",
    process: [
      { step: "01", title: "Enquiry", description: "Tell us the use case, budget and site conditions." },
      { step: "02", title: "Assessment", description: "We recommend a platform and configuration to match the job." },
      { step: "03", title: "Registration Support", description: "Assistance with DGCA registration and UIN so the drone is legally airworthy before it flies." },
      { step: "04", title: "Delivery & Handover", description: "Platform delivered, tested and handed over with an orientation flight." },
    ],
    whyHeading: "Why buy through OJAS",
    why: [
      { title: "DGCA Registration Assistance", description: "We help you through UIN registration so your drone is compliant from day one." },
      { title: "Warranty & After-Sales", description: "Every platform ships with warranty cover and ongoing service support." },
      { title: "Field-Tested Configurations", description: "Platforms are configured and tested for real operating conditions before delivery." },
      { title: "Financing on Request", description: "EMI / financing options available for eligible buyers." },
    ],
    pricingHeading: "Pricing",
    pricingNote: "Pricing depends on platform, payload and configuration.",
    pricingCta: "Get a Custom Quote",
    faq: [
      { q: "Do you help with DGCA registration?", a: "Yes — we guide you through UIN registration so the drone is legally cleared to fly before delivery." },
      { q: "Can I get a demo before buying?", a: "Yes, demo flights can be arranged at our facility or, where feasible, on-site." },
      { q: "Is financing available?", a: "EMI options are available for eligible buyers on request — ask our team for current terms." },
      { q: "What's covered under warranty?", a: "Standard warranty covers manufacturing defects and core hardware; ask for full terms specific to your platform." },
    ],
    ctaTitle: "Ready to find the right drone for your operation?",
    ctaSubtitle: "Tell us what you're trying to do — we'll recommend a platform and configuration.",
  },
  {
    slug: "drone-repair-maintenance",
    icon: "wrench",
    eyebrow: "Repair & Maintenance",
    title: "Keep your fleet flying, not grounded.",
    tagline:
      "Certified technicians, genuine parts and fast turnaround — for hardware, cameras, batteries and firmware.",
    ctaPrimary: "Book a Repair",
    ctaSecondary: "Request an AMC",
    includesHeading: "What we repair",
    includesIntro: "From a single fix to full fleet upkeep — covered under one roof.",
    includes: [
      { title: "Hardware Repair", visual: "wrench", description: "Motors, ESCs, frames and propellers — diagnosed and replaced with genuine parts." },
      { title: "Camera & Gimbal Repair", visual: "camera", description: "Calibration and repair of gimbal stabilisation and imaging payloads." },
      { title: "Battery Health & Replacement", visual: "bolt", description: "Battery diagnostics, cell health checks and safe replacement." },
      { title: "Firmware & Software Issues", visual: "database", description: "Firmware updates, calibration resets and software troubleshooting." },
    ],
    processHeading: "How servicing works",
    process: [
      { step: "01", title: "Book", description: "Log the issue online or over call — pickup or drop-off, your choice." },
      { step: "02", title: "Diagnose", description: "Certified technicians run a full diagnostic within 48 hours." },
      { step: "03", title: "Repair", description: "Genuine parts used; you're informed before any paid replacement." },
      { step: "04", title: "Return & Test Flight", description: "Unit tested before it's returned to you, ready to fly." },
    ],
    whyHeading: "Why service with OJAS",
    why: [
      { title: "Certified Technicians", description: "Every repair is handled by trained, certified hands." },
      { title: "Genuine Spare Parts", description: "No third-party substitutes — original components only." },
      { title: "48-Hour Diagnostic Promise", description: "You get a clear diagnosis and quote within 48 hours." },
      { title: "Pickup & Drop Available", description: "On-site or courier pickup for eligible locations." },
    ],
    pricingHeading: "AMC Plans",
    pricingNote: "Annual Maintenance Contracts available — fixed-cost coverage instead of pay-per-repair.",
    pricingCta: "Get a Custom Quote",
    faq: [
      { q: "How long does a repair take?", a: "Most repairs are diagnosed within 48 hours; turnaround for the fix itself depends on parts availability." },
      { q: "What is an AMC?", a: "An Annual Maintenance Contract covers scheduled servicing and priority repairs for a fixed annual cost." },
      { q: "Do you offer pickup and drop?", a: "Yes, for eligible locations — ask our team when booking." },
      { q: "Are spare parts genuine?", a: "Yes, we use only genuine or OEM-approved parts for every repair." },
    ],
    ctaTitle: "Don't let downtime ground your operation.",
    ctaSubtitle: "Book a repair or set up an AMC and keep your fleet field-ready.",
  },
  {
    slug: "drone-rental",
    icon: "route",
    eyebrow: "Drone Rental",
    title: "Access the right drone, only when you need it.",
    tagline:
      "Daily, weekly, monthly or seasonal rentals — with or without a pilot, delivered where you operate.",
    ctaPrimary: "Check Availability",
    ctaSecondary: "Get a Rental Quote",
    includesHeading: "Rental categories",
    includesIntro: "Pick the platform for the job — and the duration that fits it.",
    includes: [
      { title: "Agri Spraying Drone Rental", visual: "leaf", description: "Season-based rentals for spraying operations during peak crop cycles." },
      { title: "Survey & Mapping Drone Rental", visual: "map", description: "Short-term access to mapping platforms for one-off or periodic surveys." },
      { title: "Event & Media Drone Rental", visual: "camera", description: "Camera-equipped drones for event coverage and media production." },
      { title: "Industrial Inspection Drone Rental", visual: "factory", description: "Inspection-grade platforms for infrastructure and facility checks." },
    ],
    processHeading: "How rental works",
    process: [
      { step: "01", title: "Choose Duration", description: "Daily, weekly, monthly or full-season — whatever the job needs." },
      { step: "02", title: "Pilot Option", description: "Take the drone self-operate, or add an OJAS pilot." },
      { step: "03", title: "Delivery & Setup", description: "Delivered and set up at your site within the service area." },
      { step: "04", title: "Return", description: "Simple pickup at the end of the rental period." },
    ],
    whyHeading: "Why rent with OJAS",
    why: [
      { title: "Pilot-Included or Self-Operate", description: "Choose the option that fits your team's capability." },
      { title: "Insurance Coverage", description: "Damage coverage terms included with every rental agreement." },
      { title: "On-Site Delivery & Setup", description: "We deliver and set up within our service area." },
      { title: "Transparent Deposit Terms", description: "Clear security deposit terms, explained upfront." },
    ],
    pricingHeading: "Rental Plans",
    pricingNote: "Rates vary by platform, duration and pilot option.",
    pricingCta: "Get a Rental Quote",
    faq: [
      { q: "Can I rent without a pilot?", a: "Yes — self-operate rentals are available if you have a qualified operator." },
      { q: "Is insurance included?", a: "Yes, damage coverage terms are included; full terms are shared at booking." },
      { q: "What's the minimum rental period?", a: "Daily rentals are available; longer terms get better rates." },
      { q: "Do you deliver to the site?", a: "Yes, within our service area — confirm coverage for your location when booking." },
    ],
    ctaTitle: "Get the drone you need, exactly when you need it.",
    ctaSubtitle: "Check availability for your location and dates.",
  },
  {
    slug: "drone-training",
    icon: "network",
    eyebrow: "Drone Training",
    title: "Learn to fly. Get certified. Get to work.",
    tagline: "Structured, instructor-led training — from first flight to professional operation.",
    ctaPrimary: "Enroll Now",
    ctaSecondary: "Request Batch Schedule",
    includesHeading: "Courses offered",
    includesIntro: "Programmes for individuals, operators and organisations.",
    includes: [
      { title: "Basic / Beginner Drone Flying", visual: "drone", description: "Foundational flight training for first-time pilots." },
      {
        // TODO CONFIRM RPTO STATUS before publishing. If OJAS is NOT a DGCA-certified
        // RPTO, keep this as prep/coordination support only — do not claim certification.
        title: "Remote Pilot Certificate Course",
        visual: "book",
        description: "Structured preparation for remote pilot certification, covering theory and practical requirements.",
      },
      { title: "Agri-Drone Operator Certification", visual: "leaf", description: "Focused training for agricultural spraying and survey operations." },
      { title: "Corporate / Institutional Batch Training", visual: "network", description: "Custom batch programmes for organisations building in-house drone capability." },
    ],
    processHeading: "Course structure",
    process: [
      { step: "01", title: "Theory", description: "Classroom sessions covering regulations, safety and flight fundamentals." },
      { step: "02", title: "Simulator", description: "Simulator-based practice before real flight time." },
      { step: "03", title: "Practical Flying Hours", description: "Supervised flight hours to build real operating skill." },
      { step: "04", title: "Certification", description: "Certificate issued on successful completion of the programme." },
    ],
    whyHeading: "Why train with OJAS",
    why: [
      { title: "Instructor-Led Programme", description: "Small batches, hands-on instruction throughout." },
      { title: "Theory + Simulator + Practical", description: "A complete path from classroom to real flight." },
      { title: "Certificate on Completion", description: "Documented proof of training completion." },
      { title: "Placement Assistance", description: "Guidance connecting trained pilots to field opportunities." },
    ],
    pricingHeading: "Batches & Fees",
    pricingNote: "Fees vary by course and batch size.",
    pricingCta: "Request Batch Schedule",
    faq: [
      { q: "Do I need prior experience?", a: "No — the beginner course assumes no prior flying experience." },
      { q: "How long is the course?", a: "Duration varies by course; ask our team for the current schedule." },
      { q: "Is certification provided?", a: "A certificate of completion is issued at the end of every programme." },
      { q: "Do you offer batch training for companies?", a: "Yes — corporate and institutional batches can be arranged on request." },
    ],
    ctaTitle: "Start your journey to becoming a certified drone pilot.",
    ctaSubtitle: "Batches are forming — reserve your seat.",
  },
];

const techGroups = [
  {
    title: "Aerial & Remote Sensing",
    icon: "satellite",
    items: [
      "Multispectral Sensors",
      "Drone Data Pipeline",
      "Drone Integration",
      "Edge Computing",
      "LoRaWAN IoT Sensors",
    ],
  },
  {
    title: "Geospatial & Earth Intelligence",
    icon: "globe",
    items: [
      "SfM Orthoprocessing",
      "Sentinel-2 Satellite",
      "ISRO Bhuvan API",
      "GeoTIFF Prescription",
      "Geospatial Database",
      "Cloud Digital Twin Engine",
    ],
  },
  {
    title: "AI, ML & Decision Intelligence",
    icon: "brain",
    items: [
      "AI Disease Classifier",
      "Random Forest + LSTM",
      "Deep Learning CNN",
      "LSTM Time-Series",
      "NLP Multilingual",
      "Price Forecasting AI",
      "Weather-Adaptive AI",
    ],
  },
  {
    title: "Agriculture Intelligence",
    icon: "leaf",
    items: [
      "NDVI / NDRE Algorithm",
      "IMD Weather API",
      "Agmarknet API",
      "Agmarknet Integration",
      "e-NAM Integration",
      "HAL ERP Integration",
    ],
  },
  {
    title: "Autonomy, Fleet & Field Operations",
    icon: "route",
    items: [
      "Reinforcement Learning",
      "GPS Fleet Management",
      "Digital Booking App",
      "Predictive Maintenance",
      "Geofenced Matching",
      "Digital Muster Roll",
      "Offline-First Mobile App",
    ],
  },
  {
    title: "Digital Infrastructure & Trust",
    icon: "database",
    items: [
      "Blockchain Traceability",
      "Blockchain Audit Trail",
      "Worker Verification API",
      "UPI Direct Payment",
      "Cloud Dashboard",
      "Real-Time Dashboard",
      "API Ecosystem",
      "Digital Locker Integration",
      "PM-KUSUM Integration",
    ],
  },
];

const networkNodes = [
  [
    "MILU AI NETWORK",
    "The complete distributed intelligence architecture.",
    "network",
  ],
  ["MILU HUB", "A higher-level coordination and aggregation layer.", "globe"],
  [
    "MILU CENTRE",
    "A substantial operating environment for connected capabilities.",
    "factory",
  ],
  [
    "MILU STATION",
    "A local operational node bringing systems closer to the field.",
    "drone",
  ],
  [
    "MILU POINT",
    "A distributed edge presence where intelligence and services can reach the operating environment.",
    "signal",
  ],
];

const newsSeed = [
  ...[
    "Network architecture",
    "Service-led systems",
    "OJAS technology roadmap",
  ].map((title, i) => ({
    title,
    category: "News",
    date: `2026.0${i + 7}.0${i + 1}`,
    text: "OJAS platform content placeholder structured for future verified company updates.",
    image: ecosystemImage,
  })),
  ...[
    "Crop intelligence in the field",
    "Aerial mapping workflow",
    "Rapid situational awareness",
  ].map((title, i) => ({
    title,
    category: "Field Stories",
    date: `2026.0${i + 6}.1${i + 1}`,
    text: "Field-story placeholder ready to be replaced with a verified OJAS operation.",
    image: aboutImage,
  })),
  ...[
    "OJAS cinematic reel",
    "MILU AI visual system",
    "Aerial imaging showcase",
  ].map((title, i) => ({
    title,
    category: "Media",
    date: `2026.0${i + 5}.2${i + 1}`,
    text: "Media placeholder for future OJAS video, photography or visual assets.",
    image: technologyImage,
  })),
  ...[
    "Multispectral crop intelligence",
    "Geospatial processing pipeline",
    "AI decision intelligence",
  ].map((title, i) => ({
    title,
    category: "Technology",
    date: `2026.0${i + 4}.1${i + 2}`,
    text: "Technology editorial placeholder based on the current working stack.",
    image: technologyImage,
  })),
  ...[
    "Aerospace technology forum",
    "Field systems demonstration",
    "OJAS partner session",
  ].map((title, i) => ({
    title,
    category: "Events",
    date: `2026.0${i + 3}.2${i + 2}`,
    text: "Event placeholder ready for verified OJAS participation details.",
    image: careersImage,
  })),
];
const teamSeed = [
  {
    name: "Harshit Dixit",
    role: "Head & Chief of Staff",
    department: "Administration",
    image: harshitDixit,
    category: "LEADERSHIP",
  },
  {
    name: "Paramjeet Bind",
    role: "Tech Head – Aircraft & Missile Development",
    department: "Hardware & R&D",
    image: paramjeetBind,
    category: "AEROSPACE & R&D",
  },
  {
    name: "Abhishek Dixit",
    role: "Advisor & Head – Agriculture R&D",
    department: "Agriculture R&D",
    image: abhishekDixit,
    category: "AEROSPACE & R&D",
  },
  {
    name: "Satyam Jha",
    role: "Software Development Engineer",
    department: "IT",
    image: satyamJha,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Ishan Shrivastava",
    role: "Software Development Engineer",
    department: "IT",
    image: ishanShrivastava,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Ritesh Kumar",
    role: "Software Development Engineer",
    department: "IT",
    image: riteshKumar,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Ali Raza",
    role: "Associate Software Engineer",
    department: "IT",
    image: aliRaza,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Awadhesh Pathak",
    role: "Associate Software Engineer",
    department: "IT",
    image: awadheshPathak,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Sumit Shukla",
    role: "Software Development Engineer",
    department: "IT",
    image: sumitShukla,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Shweta Sharma",
    role: "HR & Marketing Manager",
    department: "HR & Marketing",
    image: shwetaSharma,
    category: "OPERATIONS",
  },
  {
    name: "Aditya Srivastava",
    role: "Business Analyst",
    department: "Finance",
    image: adityaSrivastava,
    category: "BUSINESS",
  },
  {
    name: "Prakhar Gupta",
    role: "UI / UX Designer",
    department: "IT",
    image: prakharGupta,
    category: "DESIGN",
  },
  {
    name: "Mayank Agarwal",
    role: "UI / UX Designer",
    department: "IT",
    image: mayankAgarwal,
    category: "DESIGN",
  },
  {
    name: "Shubham Chaudhary",
    role: "Associate Software Engineer",
    department: "IT",
    image: shubhamChaudhary,
    category: "TECHNOLOGY & AI",
  },
  {
    name: "Aviral Singh",
    role: "Digital Marketing Executive",
    department: "Digital Marketing",
    image: aviralSingh,
    category: "MARKETING",
  },
];
const careerSeed = [
  "Aerospace Engineering",
  "AI & Software",
  "Field Operations",
  "Business Systems",
  "Geospatial Technology",
  "Agriculture Technology",
  "Mission Operations",
  "Product & Platform",
].map((x, i) => ({
  title: x,
  text: "Role placeholder. Replace with an active OJAS position when hiring data is available.",
  icon: ["cpu", "brain", "drone", "network", "map", "leaf", "route", "grid"][i],
}));

function Icon({ name }: { name?: string }) {
  const glyph: Record<string, string> = {
    eye: "◉",
    earth: "◌",
    leaf: "⌁",
    grid: "⌗",
    alert: "◇",
    route: "⌁",
    drone: "✦",
    map: "⌖",
    scan: "◎",
    crop: "⌁",
    truck: "→",
    shield: "◇",
    box: "□",
    wrench: "⌁",
    book: "▱",
    network: "⌘",
    satellite: "✧",
    cpu: "◈",
    signal: "⌁",
    bolt: "ϟ",
    database: "◍",
    brain: "✦",
    target: "⊙",
    factory: "▦",
    energy: "ϟ",
    globe: "◎",
    camera: "▣",
  };
  return (
    <span className={`lineIcon icon-${name}`} aria-hidden="true">
      {glyph[name || ""] || "✦"}
    </span>
  );
}
function Question({ children }: { children: React.ReactNode }) {
  return <div className="sectionQuestion">{children}</div>;
}
function Eyebrow({
  children,
  accent = "gold",
}: {
  children: React.ReactNode;
  accent?: "gold" | "purple";
}) {
  return (
    <div className={`eyebrow ${accent}`}>
      <span />
      {children}
    </div>
  );
}
function CompanyMenu({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="companyMenu">
      <div className="companyMenuInner">
        <div>
          <Eyebrow accent="purple">COMPANY</Eyebrow>
          <h3>
            The people, places
            <br />
            and ideas behind OJAS.
          </h3>
        </div>
        <div className="companyMenuLinks">
          {[
            ["ABOUT", "/about", "What drives OJAS?"],
            ["NETWORK", "/network", "People, places & systems"],
            ["PARTNERS", "/partners", "Building the network together"],
            ["NEWS & MEDIA", "/news", "What is happening in the field?"],
            ["TEAM", "/team", "The people behind OJAS"],
            ["MILU AI", "/milu-ai", "Intelligence that connects"],
          ].map(([a, b, c]) => (
            <button
              key={b}
              onClick={() => {
                onClose();
                navigate(b);
              }}
            >
              <span>{a}</span>
              <small>{c}</small>
              <b>↗</b>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
const navDropdowns: Record<string, { label: string; url: string }[]> = {
  "/sectors": sectorData.map((s) => ({ label: s.title, url: "/sectors" })),
  "/solutions": solutions.map((s) => ({
    label: s.title,
    url: solutionPath(s.title),
  })),
  "/services": services.map((s) => ({ label: s.eyebrow, url: servicePath(s.slug) })),
  "/technology": techGroups.map((g) => ({ label: g.title, url: "/technology" })),
};
function Navbar() {
  const [theme, toggleTheme] = useTheme();
  const [path, setPath] = useState(location.pathname);
  const [menu, setMenu] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => {
    const f = () => setPath(location.pathname);
    addEventListener("popstate", f);
    return () => removeEventListener("popstate", f);
  }, []);
  useEffect(() => {
    document.body.classList.toggle("mobileNavOpen", mobileOpen);
    return () => document.body.classList.remove("mobileNavOpen");
  }, [mobileOpen]);
  const home = path === "/" || path === "/home";
  const links: [string, string, string?][] = [
    ["HOME", "/"],
    ["SECTORS", "/sectors"],
    ["SERVICES", "/services"],
    ["INFRASTRUCTURE", "/milu-ai-network"],
    ["CAREERS", "/careers"],
  ];
  const companyLinks: [string, string][] = [
    ["ABOUT", "/about"],
    ["PARTNERS", "/partners"],
    ["NEWS & MEDIA", "/news"],
    ["TEAM", "/team"],
    ["MILU AI", "/milu-ai"],
  ];
  const handle = (url: string, section?: string) => {
    setMenu(false);
    setMobileOpen(false);
    if (home && section) go(section);
    else navigate(url);
  };
  return (
    <>
      <header className="navbar">
        <button
          className="brand"
          onClick={() => (home ? go("home") : navigate("/"))}
          aria-label="OJAS home"
        >
          <img src={logo} alt="OJAS" />
        </button>
        <button
          className={`mobileMenuToggle ${mobileOpen ? "open" : ""}`}
          aria-label="Toggle navigation"
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((v) => !v)}
        >
          <i />
          <i />
          <i />
        </button>
        <div className="navDesktopLinks">
          {links.map(([label, url, section]) => (
            <div key={url} className="navItem">
              <button
                className={!home && path === url ? "active" : ""}
                onClick={() => handle(url, section)}
              >
                {label}
                {navDropdowns[url] && <span className="menuCaret">⌄</span>}
              </button>
              {navDropdowns[url] && (
                <div className="navDropdownPanel">
                  {navDropdowns[url].map((d, i) => (
                    <button key={d.label + i} onClick={() => handle(d.url)}>
                      {d.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
          <button
            className={menu ? "active" : ""}
            onClick={() => setMenu((v) => !v)}
          >
            COMPANY <span className="menuCaret">⌄</span>
          </button>
        </div>
        <div className="navRight">
          <button
            className="themeIcon"
            aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
            onClick={toggleTheme}
          >
            <span>{theme === "dark" ? "☼" : "☾"}</span>
          </button>
          <button className="partner" onClick={() => navigate("/contact")}>
            CONTACT <span>→</span>
          </button>
        </div>
      </header>
      <div
        className={`mobileNavOverlay ${mobileOpen ? "is-open" : ""}`}
        aria-hidden={!mobileOpen}
      >
        <div className="mobileNavHeader">
          <button
            className="mobileNavBrand"
            onClick={() => handle("/")}
            aria-label="OJAS home"
          >
            <img src={logo} alt="OJAS" />
          </button>
          <button
            className="mobileNavClose"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation"
          >
            <span />
            <span />
          </button>
        </div>
        <div className="mobileNavIntro">
          <small>OJAS / NAVIGATION</small>
          <p>Explore the connected system.</p>
        </div>
        <div className="mobileNavLinks">
          {links.map(([label, url, section], i) => (
            <button
              key={url}
              className={!home && path === url ? "active" : ""}
              onClick={() => handle(url, section)}
            >
              <small>{String(i + 1).padStart(2, "0")}</small>
              <span>{label}</span>
              <b>↗</b>
            </button>
          ))}
        </div>
        <div className="mobileCompanyLinks">
          <div>
            <small>COMPANY</small>
            <span>THE OJAS STORY</span>
          </div>
          <div className="mobileCompanyGrid">
            {companyLinks.map(([label, url]) => (
              <button
                key={url}
                className={path === url ? "active" : ""}
                onClick={() => handle(url)}
              >
                {label}
                <b>↗</b>
              </button>
            ))}
          </div>
        </div>
        <div className="mobileNavActions">
          <button className="partner" onClick={() => handle("/contact")}>
            START A CONVERSATION <span>→</span>
          </button>
        </div>
      </div>
      <CompanyMenu
        open={menu}
        onClose={() => {
          setMenu(false);
          setMobileOpen(false);
        }}
      />
    </>
  );
}

function ContactBlock() {
  return (
    <div className="contactLayout">
      <div className="contactPitch">
        <Eyebrow>CONTACT</Eyebrow>
        <h2>
          Let's build <em>what comes next.</em>
        </h2>
        <p>
          For partnerships, technology conversations, projects, services or
          careers.
        </p>
        <div className="contactDetails">
          <div>
            <small>EMAIL</small>
            <a href="mailto:info@ojasspace.com">info@ojasspace.com</a>
          </div>
          <div>
            <small>PHONE</small>
            <a href="tel:01354316767">0135 431 6767</a>
          </div>
          <div>
            <small>OFFICE</small>
            <span>Imperial Heights, Dehradun, Uttarakhand</span>
          </div>
        </div>
      </div>
    </div>
  );
}
function Home() {
  return (
    <>
      <Hero />
      <Solutions />
    </>
  );
}

function pageLabel() {
  const p = location.pathname;
  if (p === "/sectors") return "SECTORS";
  if (p === "/solutions") return "SOLUTIONS";
  if (p.startsWith("/solutions/")) return "SOLUTION";
  if (p === "/services") return "SERVICES";
  if (p.startsWith("/services/")) return "SERVICE";
  if (p === "/technology") return "TECHNOLOGY";
  if (p === "/milu-ai") return "MILU AI";
  if (p === "/milu-ai-network") return "INFRASTRUCTURE";
  if (p === "/network") return "NETWORK";
  if (p === "/partners") return "PARTNERS";
  if (p === "/news") return "NEWS & MEDIA";
  if (p === "/team") return "TEAM";
  if (p === "/careers") return "CAREERS";
  if (p === "/about") return "ABOUT";
  if (p === "/contact") return "CONTACT";
  return "OJAS";
}
function DetailHero({
  question,
  title,
  description,
  image,
  label,
}: {
  question: string;
  title: React.ReactNode;
  description: string;
  image?: string;
  label?: string;
}) {
  return (
    <section
      className="detailHero"
      style={
        image
          ? {
            backgroundImage: `linear-gradient(90deg,rgba(3,2,8,.94),rgba(3,2,8,.55),rgba(3,2,8,.18)),url(${image})`,
          }
          : {}
      }
    >
      <div>
        <Question>{question}</Question>
        <Eyebrow>{label || pageLabel()}</Eyebrow>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
    </section>
  );
}
function SectionBlock({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="detailBlock">
      <div className="detailBlockHead">
        <Question>{eyebrow}</Question>
        <h2>{title}</h2>
      </div>
      {children}
    </section>
  );
}
function IconCards({ items }: { items: Item[] }) {
  return (
    <div className="iconCards">
      {items.map((x, i) => (
        <article key={x.title}>
          <div className="iconBubble">
            <Icon name={x.icon} />
          </div>
          <small>0{(i % 9) + 1}</small>
          <h3>{x.title}</h3>
          <p>{x.text}</p>
        </article>
      ))}
    </div>
  );
}
function DetailList({ items }: { items: string[] }) {
  return (
    <div className="detailList">
      {items.map((x, i) => (
        <div key={x}>
          <span>{String(i + 1).padStart(2, "0")}</span>
          <b>{x}</b>
          <i>+</i>
        </div>
      ))}
    </div>
  );
}
function StandardPage({
  question,
  title,
  description,
  image,
  children,
}: {
  question: string;
  title: React.ReactNode;
  description: string;
  image?: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <DetailHero
        question={question}
        title={title}
        description={description}
        image={image}
      />
      <div className="detailMain">{children}</div>
    </>
  );
}

function SectorsPage() {
  return (
    <StandardPage
      question="Where does OJAS operate?"
      title={
        <>
          Systems for <em>different worlds.</em>
        </>
      }
      description="Sectors describe the contexts in which OJAS applies aerospace systems, intelligence and field capability."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="Six operating environments"
        title={
          <>
            One connected <em>approach.</em>
          </>
        }
      >
        <p className="wideLead">
          Sectors are parallel entry points. A single sector can draw from
          multiple solutions, services and technologies as the mission requires.
        </p>
        <div className="sectorDetailGrid">
          {sectorData.map((x, i) => (
            <article key={x.title}>
              <div className="iconBubble">
                <Icon name={x.icon} />
              </div>
              <small>0{i + 1}</small>
              <h3>{x.title}</h3>
              <p>{x.text}</p>
              <button onClick={() => navigate("/solutions")}>
                EXPLORE SOLUTIONS <span>→</span>
              </button>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="The relationship"
        title={
          <>
            Context → capability → <em>action.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "Sector",
              text: "The environment or operating context where a requirement exists.",
              icon: "globe",
            },
            {
              title: "Solution",
              text: "The problem or outcome OJAS helps address.",
              icon: "target",
            },
            {
              title: "Service",
              text: "The operational capability a customer can engage OJAS to deliver.",
              icon: "drone",
            },
          ]}
        />
      </SectionBlock>
    </StandardPage>
  );
}

function SolutionsPage() {
  return (
    <StandardPage
      question="What problems do we solve?"
      title={
        <>
          Intelligence <em>for the real world.</em>
        </>
      }
      description="Six solution domains connect OJAS services and technology to concrete problems and outcomes."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="Six solution domains"
        title={
          <>
            Problem → intelligence → <em>action.</em>
          </>
        }
      >
        <p className="wideLead">
          Each solution starts with a real-world requirement and connects
          observation, analysis, operational capability and relevant technology
          around the desired outcome.
        </p>
        <div className="solutionDetailGrid">
          {solutions.map((s, i) => (
            <article
              key={s.title}
              onClick={() => navigate(solutionPath(s.title))}
            >
              <div className="cardMedia">
                {s.image ? <img src={s.image} alt="" /> : <Icon name="route" />}
              </div>
              <small>0{i + 1}</small>
              <h3>{s.title}</h3>
              <p>{s.text}</p>
              <button>
                EXPLORE <span>→</span>
              </button>
            </article>
          ))}
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

const solutionInfo: Record<
  string,
  {
    heading: string;
    intro: string;
    cap: string[];
    sectors: string[];
    services: string[];
    tech: string[];
  }
> = {
  "Surveillance & Reconnaissance": {
    heading: "Awareness from above.",
    intro:
      "Persistent aerial intelligence for environments where broader visibility, remote access and timely information matter.",
    cap: [
      "Aerial surveillance",
      "Reconnaissance missions",
      "Remote observation",
      "Situational awareness",
      "Real-time monitoring",
      "Specialized aerial missions",
    ],
    sectors: ["Security & Public Safety", "Infrastructure & Industrial"],
    services: [
      "Site Monitoring",
      "Surveillance & Reconnaissance",
      "Real-Time Aerial Intelligence",
    ],
    tech: [
      "Aerial & Remote Sensing",
      "Geospatial & Earth Intelligence",
      "AI, ML & Decision Intelligence",
    ],
  },
  "Earth Observation": {
    heading: "See the bigger picture.",
    intro:
      "Combine aerial, geospatial and remote-sensing information to understand landscapes, assets and change at scale.",
    cap: [
      "Remote sensing",
      "Aerial observation",
      "Survey & mapping",
      "Photogrammetry",
      "GIS and geospatial analysis",
      "Change detection",
    ],
    sectors: [
      "Geospatial & Visual Intelligence",
      "Agriculture & Rural Systems",
      "Energy & Utilities",
    ],
    services: [
      "Aerial Mapping",
      "Photogrammetry & 3D Mapping",
      "Geospatial Intelligence",
    ],
    tech: ["Aerial & Remote Sensing", "Geospatial & Earth Intelligence"],
  },
  "Precision Agriculture": {
    heading: "From field data to better decisions.",
    intro:
      "Bring crop imagery, field information and operational data together to support more precise agricultural decisions and interventions.",
    cap: [
      "Crop mapping",
      "Crop monitoring",
      "Crop-health assessment",
      "Pest and disease identification",
      "Precision spraying",
      "Yield and field intelligence",
    ],
    sectors: ["Agriculture & Rural Systems"],
    services: ["Crop Health Monitoring", "Precision Spraying", "Field Mapping"],
    tech: [
      "Agriculture Intelligence",
      "AI, ML & Decision Intelligence",
      "Aerial & Remote Sensing",
    ],
  },
  "Infrastructure Monitoring": {
    heading: "Inspect what keeps the world moving.",
    intro:
      "Use aerial observation and specialized sensing to document, inspect and monitor critical infrastructure and assets.",
    cap: [
      "Infrastructure inspection",
      "Construction monitoring",
      "Asset monitoring",
      "Power-line inspection",
      "Solar infrastructure monitoring",
      "Thermal and 3D inspection",
    ],
    sectors: ["Infrastructure & Industrial", "Energy & Utilities"],
    services: [
      "Infrastructure Inspection",
      "Construction Monitoring",
      "Power & Utility Inspection",
    ],
    tech: [
      "Aerial & Remote Sensing",
      "Geospatial & Earth Intelligence",
      "Digital Infrastructure & Trust",
    ],
  },
  "Disaster Response": {
    heading: "See sooner. Respond faster.",
    intro:
      "Rapid aerial observation and geospatial intelligence for situations where access, awareness and time are critical.",
    cap: [
      "Emergency observation",
      "Disaster reconnaissance",
      "Flood response support",
      "Search and rescue support",
      "Emergency mapping",
      "Emergency payload delivery",
    ],
    sectors: ["Security & Public Safety", "Logistics & Delivery"],
    services: [
      "Flood Assessment",
      "Search & Rescue Support",
      "Emergency Mapping",
    ],
    tech: [
      "Aerial & Remote Sensing",
      "Geospatial & Earth Intelligence",
      "AI, ML & Decision Intelligence",
    ],
  },
  "Autonomous Logistics": {
    heading: "Logistics beyond the road.",
    intro:
      "Aerial and intelligent logistics capabilities for medical, agricultural, emergency and remote-area delivery requirements.",
    cap: [
      "Medical delivery",
      "Agricultural-input delivery",
      "Emergency delivery",
      "Remote-area delivery",
      "Last-mile UAV delivery",
      "Route and mission coordination",
    ],
    sectors: ["Logistics & Delivery", "Agriculture & Rural Systems"],
    services: [
      "Medical Delivery",
      "Emergency Payload Delivery",
      "Last-Mile Aerial Logistics",
    ],
    tech: [
      "Autonomy, Fleet & Field Operations",
      "Aerial & Remote Sensing",
      "Digital Infrastructure & Trust",
    ],
  },
};
function SolutionPage({ s }: { s: Item }) {
  const d = solutionInfo[s.title];
  return (
    <StandardPage
      question={`Solution / ${s.title}`}
      title={
        <>
          {s.title}
          <br />
          <em>{d.heading}</em>
        </>
      }
      description={d.intro}
      image={s.image}
    >
      <SectionBlock
        eyebrow="The operating model"
        title={
          <>
            Observe. Understand. <em>Act.</em>
          </>
        }
      >
        <div className="solutionFlow">
          <div>
            {[
              [
                "Observe",
                "Capture the right information from the environment.",
                "eye",
              ],
              [
                "Understand",
                "Interpret observations with spatial, operational and intelligent systems.",
                "brain",
              ],
              [
                "Act",
                "Connect insight to people, platforms and systems that can respond.",
                "bolt",
              ],
            ].map(([a, b, ic], i) => (
              <React.Fragment key={a}>
                <article>
                  <div className="iconBubble">
                    <Icon name={ic} />
                  </div>
                  <small>0{i + 1}</small>
                  <h3>{a}</h3>
                  <p>{b}</p>
                </article>
                {i < 2 && <span>→</span>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Capabilities"
        title={
          <>
            What the solution can <em>enable.</em>
          </>
        }
      >
        <DetailList items={d.cap} />
      </SectionBlock>
      <SectionBlock
        eyebrow="Connected OJAS stack"
        title={
          <>
            Where it connects across the <em>system.</em>
          </>
        }
      >
        <div className="relationshipGrid">
          <div>
            <small>SECTORS</small>
            {d.sectors.map((x) => (
              <b key={x}>{x}</b>
            ))}
          </div>
          <div>
            <small>SERVICES</small>
            {d.services.map((x) => (
              <button key={x} onClick={() => navigate(servicePath(x))}>
                {x}
                <span>↗</span>
              </button>
            ))}
          </div>
          <div>
            <small>TECHNOLOGY</small>
            {d.tech.map((x) => (
              <b key={x}>{x}</b>
            ))}
          </div>
        </div>
      </SectionBlock>
      <button className="largeCta" onClick={() => navigate("/contact")}>
        WORK WITH OJAS →
      </button>
    </StandardPage>
  );
}

function ServicesPage() {
  return (
    <StandardPage
      question="What can OJAS do for you?"
      title={
        <>
          Four services. <em>One fleet, fully supported.</em>
        </>
      }
      description="OJAS Aerospace's core services: Drone Sale, Repair & Maintenance, Rental, and Training — everything needed to acquire, operate and keep a drone fleet field-ready."
      image={careersImage}
    >
      <SectionBlock
        eyebrow="Our services"
        title={
          <>
            Everything a drone <em>needs, in one place.</em>
          </>
        }
      >
        <div className="serviceDirectory">
          {services.map((s, i) => (
            <article key={s.slug} className="serviceOverviewCard">
              <div className="serviceGroupHead">
                <div className="iconBubble">
                  <Icon name={s.icon} />
                </div>
                <div>
                  <small>0{i + 1}</small>
                  <h3>{s.eyebrow}</h3>
                  <p>{s.tagline}</p>
                </div>
              </div>
              <button
                className="serviceOverviewLink"
                onClick={() => navigate(servicePath(s.slug))}
              >
                EXPLORE {s.eyebrow.toUpperCase()} <span>→</span>
              </button>
            </article>
          ))}
        </div>
      </SectionBlock>
    </StandardPage>
  );
}
function SpecsTable({ specs }: { specs: { label: string; value: string }[] }) {
  return (
    <dl className="specsTable">
      {specs.map((s) => (
        <div key={s.label}>
          <dt>{s.label}</dt>
          <dd>{s.value}</dd>
        </div>
      ))}
    </dl>
  );
}
function ProcessSteps({ steps }: { steps: ServiceStep[] }) {
  return (
    <div className="processSteps">
      {steps.map((s) => (
        <article key={s.step}>
          <small>{s.step}</small>
          <h3>{s.title}</h3>
          <p>{s.description}</p>
        </article>
      ))}
    </div>
  );
}
function FAQList({ items }: { items: ServiceFAQ[] }) {
  return (
    <div className="serviceFaqList">
      {items.map((f) => (
        <div key={f.q} className="serviceFaqItem">
          <b>{f.q}</b>
          <p>{f.a}</p>
        </div>
      ))}
    </div>
  );
}
function ServiceDetailPage({ slug }: { slug: string }) {
  const s = services.find((x) => x.slug === slug);
  if (!s) return <ServicesPage />;
  return (
    <StandardPage
      question={`Service / ${s.eyebrow}`}
      title={<>{s.title}</>}
      description={s.tagline}
      image={s.slug === "drone-training" ? teamFieldDeployment : technologyImage}
    >
      <SectionBlock
        eyebrow={s.includesHeading}
        title={
          <>
            {s.includesIntro}
          </>
        }
      >
        <div className="serviceOfferingGrid">
          {s.includes.map((o) => (
            <article key={o.title} className="serviceOfferingCard">
              <div className="offeringMedia">
                <Icon name={o.visual} />
              </div>
              <h3>{o.title}</h3>
              <p>{o.description}</p>
              {o.specs && <SpecsTable specs={o.specs} />}
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="How it works"
        title={<>{s.processHeading}</>}
      >
        <ProcessSteps steps={s.process} />
      </SectionBlock>
      <SectionBlock eyebrow="Why OJAS" title={<>{s.whyHeading}</>}>
        <IconCards
          items={s.why.map((w) => ({
            title: w.title,
            text: w.description,
            icon: "shield",
          }))}
        />
      </SectionBlock>
      <SectionBlock eyebrow="Pricing" title={<>{s.pricingHeading}</>}>
        <p className="wideLead">{s.pricingNote}</p>
        <button className="largeCta" onClick={() => navigate("/contact")}>
          {s.pricingCta.toUpperCase()} →
        </button>
      </SectionBlock>
      <SectionBlock eyebrow="FAQ" title={<>Common questions.</>}>
        <FAQList items={s.faq} />
      </SectionBlock>
      <div className="serviceFinalCta">
        <h2>{s.ctaTitle}</h2>
        <p>{s.ctaSubtitle}</p>
        <div className="serviceFinalCtaButtons">
          <button className="largeCta" onClick={() => navigate("/contact")}>
            {s.ctaPrimary.toUpperCase()} →
          </button>
          <button className="largeCtaGhost" onClick={() => navigate("/contact")}>
            {s.ctaSecondary.toUpperCase()}
          </button>
        </div>
      </div>
    </StandardPage>
  );
}

function TechnologyPage() {
  return (
    <StandardPage
      question="How do we make it possible?"
      title={
        <>
          Technology <em>built for the field.</em>
        </>
      }
      description="A coherent working stack across sensing, geospatial intelligence, AI, agriculture, autonomy and digital infrastructure."
      image={technologyImage}
    >
      <SectionBlock
        eyebrow="Technology domains"
        title={
          <>
            A stack designed to <em>connect.</em>
          </>
        }
      >
        <div className="techDomainGrid">
          {techGroups.map((g, i) => (
            <article key={g.title}>
              <div className="iconBubble">
                <Icon name={g.icon} />
              </div>
              <small>0{i + 1}</small>
              <h3>{g.title}</h3>
              <p>
                Working technologies and integrations that support this
                capability domain.
              </p>
              <DetailList items={g.items} />
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Applied R&D"
        title={
          <>
            Research → prototype → deploy → <em>feedback.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "Research",
              text: "Explore emerging technologies and identify useful applications.",
              icon: "brain",
            },
            {
              title: "Prototype",
              text: "Build and test systems around real requirements.",
              icon: "cpu",
            },
            {
              title: "Deploy",
              text: "Move useful capability into operational environments.",
              icon: "drone",
            },
            {
              title: "Feedback",
              text: "Use field signals to improve systems and guide future R&D.",
              icon: "network",
            },
          ]}
        />
      </SectionBlock>
    </StandardPage>
  );
}

function MiluPage() {
  const steps = [
    [
      "SENSE",
      "Collect signals from the field and connected systems.",
      "signal",
    ],
    ["UNDERSTAND", "Fuse information and interpret it in context.", "brain"],
    ["PREDICT", "Identify likely changes, risks and opportunities.", "target"],
    [
      "DECIDE",
      "Turn intelligence into clear priorities and recommendations.",
      "cpu",
    ],
    [
      "ACT",
      "Connect decisions to people, services and operational systems.",
      "bolt",
    ],
    [
      "LEARN",
      "Feed outcomes back into the network, services and R&D.",
      "network",
    ],
  ];
  return (
    <StandardPage
      question="How does information become intelligence?"
      title={
        <>
          Intelligence <em>that connects.</em>
        </>
      }
      description="MILU AI is OJAS's intelligence layer: connecting field signals, operational data and context so the network can understand, decide, act and learn."
      image={miluImage}
    >
      <SectionBlock
        eyebrow="How MILU thinks"
        title={
          <>
            Sense → understand → <em>act.</em>
          </>
        }
      >
        <p className="wideLead">
          MILU is not a chatbot or a standalone dashboard. It is an operational
          intelligence layer that connects distributed information to decisions
          and then back to real-world action.
        </p>
        <div className="miluAiFlow">
          {steps.map(([a, b, ic], i) => (
            <React.Fragment key={a}>
              <article>
                <div className="iconBubble">
                  <Icon name={ic} />
                </div>
                <small>{String(i + 1).padStart(2, "0")}</small>
                <h3>{a}</h3>
                <p>{b}</p>
              </article>
              {i < steps.length - 1 && <span className="miluArrow">→</span>}
            </React.Fragment>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="What feeds MILU"
        title={
          <>
            Signals from across the <em>network.</em>
          </>
        }
      >
        <div className="miluSourceGrid">
          <article>
            <Icon name="drone" />
            <h3>Field & aerial data</h3>
            <p>
              UAVs, sensors, imagery and observations from operations in the
              physical world.
            </p>
          </article>
          <article>
            <Icon name="map" />
            <h3>Spatial context</h3>
            <p>
              Geospatial, satellite, weather and environmental information that
              explains where and when things are changing.
            </p>
          </article>
          <article>
            <Icon name="cpu" />
            <h3>Operational systems</h3>
            <p>
              Service activity, CRM/ERP signals, workflows and other business or
              operational information.
            </p>
          </article>
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="The feedback loop"
        title={
          <>
            Services learn. The system <em>improves.</em>
          </>
        }
      >
        <div className="miluFeedback">
          <b>SERVICE</b>
          <span>→</span>
          <b>DATA</b>
          <span>→</span>
          <b>INTELLIGENCE</b>
          <span>→</span>
          <b>DECISION</b>
          <span>→</span>
          <b>ACTION</b>
          <span>→</span>
          <b>OUTCOME</b>
          <span>↺</span>
        </div>
        <p className="wideLead">
          Outcomes and feedback can improve future service delivery, guide
          decision-making and help direct OJAS technology development and
          research.
        </p>
      </SectionBlock>
      <button
        className="networkBanner"
        onClick={() => navigate("/milu-ai-network")}
      >
        EXPLORE MILU AI NETWORK →
      </button>
    </StandardPage>
  );
}

function InfrastructurePage() {
  return (
    <StandardPage
      question="Where does the network live?"
      title={
        <>
          MILU AI <em>Network.</em>
        </>
      }
      description="Distributed infrastructure that brings intelligence, field capability and connected operations closer to where work happens."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="The infrastructure hierarchy"
        title={
          <>
            Intelligence across <em>distance.</em>
          </>
        }
      >
        <div className="networkDetailStack">
          {networkNodes.map(([x, d, ic], i) => (
            <article key={x}>
              <div className="iconBubble">
                <Icon name={ic} />
              </div>
              <small>0{i + 1}</small>
              <h2>{x}</h2>
              <p>{d}</p>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="What infrastructure enables"
        title={
          <>
            Closer to the <em>operation.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "Drone operations",
              text: "Operational environments for deployment, mission preparation and field support.",
              icon: "drone",
            },
            {
              title: "Data & connectivity",
              text: "Connected infrastructure can support data collection, transfer and local context.",
              icon: "signal",
            },
            {
              title: "Training & support",
              text: "Capability can be supported through training, maintenance and operational assistance.",
              icon: "wrench",
            },
            {
              title: "Service delivery",
              text: "Distributed nodes can bring customer-facing services closer to operating environments.",
              icon: "bolt",
            },
          ]}
        />
      </SectionBlock>
      <button className="largeCta" onClick={() => navigate("/network")}>
        EXPLORE THE NETWORK →
      </button>
    </StandardPage>
  );
}

function NetworkPage() {
  return (
    <StandardPage
      question="Who and what is connected?"
      title={
        <>
          A network built <em>beyond the screen.</em>
        </>
      }
      description="The OJAS Network connects people, places, platforms, partners, customers and operations around the wider intelligence system."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="Network layers"
        title={
          <>
            People. Places. Systems. <em>Operations.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "People",
              text: "Engineers, operators, field teams, customers, partners and domain contributors.",
              icon: "network",
            },
            {
              title: "Places",
              text: "MILU infrastructure and the environments in which services and operations occur.",
              icon: "globe",
            },
            {
              title: "Platforms",
              text: "UAVs, sensors, software and other systems connected to missions.",
              icon: "drone",
            },
            {
              title: "Operations",
              text: "Services and field workflows that turn capability into outcomes.",
              icon: "route",
            },
          ]}
        />
      </SectionBlock>
      <SectionBlock
        eyebrow="The national view"
        title={
          <>
            A distributed <em>India network.</em>
          </>
        }
      >
        <div className="networkMapPlaceholder">
          <div className="mapGlow">INDIA</div>
          <span className="node n1" />
          <span className="node n2" />
          <span className="node n3" />
          <span className="node n4" />
          <span className="node n5" />
          <p>
            Interactive network mapping can be populated with verified OJAS
            nodes, capabilities and status as deployment data becomes available.
          </p>
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Infrastructure relationship"
        title={
          <>
            Structure → connection → <em>action.</em>
          </>
        }
      >
        <div className="feedbackLoop">
          <div>
            <Icon name="factory" />
            <b>Infrastructure</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="network" />
            <b>Network</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="brain" />
            <b>MILU AI</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="drone" />
            <b>Services</b>
          </div>
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

function PartnersPage() {
  const partners = [
    [
      "Technology",
      "Technology providers, platforms, sensing systems and digital infrastructure that strengthen the OJAS stack.",
      "cpu",
    ],
    [
      "Agriculture & Industry",
      "Domain organisations that connect OJAS capabilities to real operational environments.",
      "factory",
    ],
    [
      "Institutional",
      "Public-sector, research and institutional relationships supporting broader deployment and capability building.",
      "book",
    ],
    [
      "Deployment",
      "Local operators and implementation relationships that help services reach the field.",
      "drone",
    ],
    [
      "Strategic",
      "Long-term relationships around research, expansion, investment and ecosystem development.",
      "target",
    ],
  ];
  return (
    <StandardPage
      question="Who do we build with?"
      title={
        <>
          Building the network <em>together.</em>
        </>
      }
      description="The OJAS ecosystem brings complementary organisations, capabilities and operating environments into a connected network."
      image={technologyImage}
    >
      <SectionBlock
        eyebrow="Partner ecosystem"
        title={
          <>
            Different strengths. <em>Connected outcomes.</em>
          </>
        }
      >
        <p className="wideLead">
          The ecosystem is the relationship model: different kinds of partners
          contribute different strengths to technology, deployment, operations
          and long-term growth.
        </p>
        <div className="partnerEcosystem">
          <div className="ecosystemCore">
            <span>OJAS</span>
            <small>CONNECTED NETWORK</small>
          </div>
          {partners.map((p, i) => (
            <article key={p[0]} className={`ecoPartner eco${i + 1}`}>
              <Icon name={p[2]} />
              <div>
                <small>{String(i + 1).padStart(2, "0")}</small>
                <h3>{p[0]}</h3>
                <p>{p[1]}</p>
              </div>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Partner directory"
        title={
          <>
            Explore ways to <em>connect.</em>
          </>
        }
      >
        <p className="wideLead">
          This directory is intentionally distinct from the ecosystem map: it is
          the practical entry point for future partner profiles, programmes and
          enquiries.
        </p>
        <div className="partnerDirectory">
          {partners.map((p, i) => (
            <article key={p[0]}>
              <div className="partnerDirectoryTop">
                <Icon name={p[2]} />
                <small>PARTNER PATH {String(i + 1).padStart(2, "0")}</small>
              </div>
              <h3>{p[0]}</h3>
              <p>{p[1]}</p>
              <div className="partnerTags">
                <span>PROFILE READY</span>
                <span>CAPABILITY</span>
              </div>
              <button onClick={() => navigate("/contact")}>
                EXPLORE PARTNERSHIP ↗
              </button>
            </article>
          ))}
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

function NewsPage() {
  const [filter, setFilter] = useState("All");
  const filters = [
    "All",
    "News",
    "Field Stories",
    "Media",
    "Technology",
    "Events",
  ];
  const shown =
    filter === "All" ? newsSeed : newsSeed.filter((x) => x.category === filter);
  return (
    <StandardPage
      question="What is happening in the field?"
      title={
        <>
          News, stories & <em>media.</em>
        </>
      }
      description="A structured editorial layer for company developments, field stories, technology updates, events and visual media."
      image={technologyImage}
    >
      <SectionBlock
        eyebrow="Latest"
        title={
          <>
            The OJAS <em>story in motion.</em>
          </>
        }
      >
        <div className="filterBar">
          {filters.map((f) => (
            <button
              key={f}
              className={filter === f ? "active" : ""}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="newsGrid">
          {shown.map((n, i) => (
            <article key={`${n.category}-${n.title}`}>
              <div
                className="newsImage"
                style={{ backgroundImage: `url(${n.image})` }}
              />
              <div className="newsMeta">
                <span>{n.category}</span>
                <small>{n.date}</small>
              </div>
              <h3>{n.title}</h3>
              <p>{n.text}</p>
              <button>
                READ STORY <span>↗</span>
              </button>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Content model"
        title={
          <>
            Every story can connect back to the <em>system.</em>
          </>
        }
      >
        <p className="wideLead">
          News and field stories can eventually link to sectors, solutions,
          services, technology and network locations, making the content layer
          useful for discovery rather than a standalone archive.
        </p>
      </SectionBlock>
    </StandardPage>
  );
}

function TeamPage() {
  const [filter, setFilter] = useState("ALL");

  const filters = [
    "ALL",
    ...Array.from(new Set(teamSeed.map((member) => member.category))),
  ];

  const shown =
    filter === "ALL"
      ? teamSeed
      : teamSeed.filter((member) => member.category === filter);

  return (
    <StandardPage
      question="Who builds it?"
      title={
        <>
          The people <em>behind OJAS.</em>
        </>
      }
      description="The multidisciplinary team building OJAS across technology, aerospace R&D, operations, business, design and field-focused systems."
      image={teamDroneLab}
    >
      <SectionBlock
        eyebrow="Culture & Mission"
        title={
          <>
            From the R&D lab to <em>field execution.</em>
          </>
        }
      >
        <div className="teamDualShowcase">
          <div className="teamDualCard">
            <img src={teamDroneLab} alt="OJAS R&D and MILU Lab Team" />
            <div className="teamDualOverlay">
              <span className="teamDualBadge">CORE R&D & ENGINEERING HUB</span>
              <h3>Aerospace, AI & Drone Port Lab</h3>
              <p>Designing intelligent aerial hardware, autonomous docking systems, and edge AI in-house.</p>
            </div>
          </div>

          <div className="teamDualCard">
            <img src={teamFieldDeployment} alt="OJAS Field Operations and Mountain Missions" />
            <div className="teamDualOverlay">
              <span className="teamDualBadge">FIELD MISSIONS & REGIONAL IMPACT</span>
              <h3>High-Altitude & Grassroots Deployment</h3>
              <p>Empowering local operators, certified pilots, and field technicians across rugged terrain and agriculture.</p>
            </div>
          </div>
        </div>
      </SectionBlock>

      <SectionBlock
        eyebrow="Our team"
        title={
          <>
            People building <em>the intelligent network.</em>
          </>
        }
      >
        <div className="filterBar">
          {filters.map((f) => (
            <button
              key={f}
              className={filter === f ? "active" : ""}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="teamGrid">
          {shown.map((member, i) => (
            <article key={member.name} className="teamCard">
              <div className="teamPortrait">
                <img src={member.image} alt={member.name} />
              </div>

              <small>{String(i + 1).padStart(2, "0")}</small>

              <h3>{member.name}</h3>

              <p className="teamRole">{member.role}</p>

              <span>{member.department}</span>
            </article>
          ))}
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

function CareersPage() {
  const [filter, setFilter] = useState("ALL");
  const filters = [
    "ALL",
    "ENGINEERING",
    "AI & SOFTWARE",
    "AEROSPACE",
    "AGRICULTURE",
    "OPERATIONS",
    "FIELD",
    "BUSINESS",
  ];
  const shown =
    filter === "ALL"
      ? careerSeed
      : careerSeed.filter((x, i) => {
        const map = [
          "AEROSPACE",
          "AI & SOFTWARE",
          "FIELD",
          "BUSINESS",
          "ENGINEERING",
          "AGRICULTURE",
          "OPERATIONS",
          "ENGINEERING",
        ];
        return map[i] === filter;
      });
  return (
    <StandardPage
      question="Who wants to build it with us?"
      title={
        <>
          Work where <em>systems meet reality.</em>
        </>
      }
      description="Careers across aerospace, intelligent systems, software, field technology, geospatial systems and business operations."
      image={careersImage}
    >
      <SectionBlock
        eyebrow="Why OJAS"
        title={
          <>
            Build the next <em>layer.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "Cross-disciplinary work",
              text: "Work across aerospace, AI, field systems, operations and business technology.",
              icon: "network",
            },
            {
              title: "Real-world systems",
              text: "Build technology intended to operate beyond the screen.",
              icon: "drone",
            },
            {
              title: "Research to deployment",
              text: "Contribute across experimentation, engineering and field learning.",
              icon: "brain",
            },
          ]}
        />
      </SectionBlock>
      <SectionBlock
        eyebrow="Open positions"
        title={
          <>
            Find where you <em>fit.</em>
          </>
        }
      >
        <div className="filterBar">
          {filters.map((f) => (
            <button
              key={f}
              className={filter === f ? "active" : ""}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="jobGrid">
          {shown.map((x, i) => (
            <article key={x.title}>
              <small>0{i + 1}</small>
              <h3>{x.title}</h3>
              <p>{x.text}</p>
              <div>
                <span>ROLE PLACEHOLDER</span>
                <button onClick={() => navigate("/contact")}>
                  EXPRESS INTEREST ↗
                </button>
              </div>
            </article>
          ))}
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

function AboutPage() {
  return (
    <StandardPage
      question="What drives OJAS?"
      title={
        <>
          Engineering <em>what comes next.</em>
        </>
      }
      description="OJAS is being shaped as a service-led systems company bringing aerospace, intelligent systems, infrastructure and applied R&D together."
      image={aboutImage}
    >
      <SectionBlock
        eyebrow="The OJAS idea"
        title={
          <>
            Service-led. Technology-driven. <em>Intelligence-connected.</em>
          </>
        }
      >
        <p className="wideLead">
          Real customer and field requirements generate service work. Service
          work generates information and signals. Those signals can improve
          decision-making and help guide technology development and research
          direction — creating a feedback loop that improves future services.
        </p>
        <IconCards
          items={[
            {
              title: "Build",
              text: "Develop and integrate aerospace, software, sensing and field systems around real requirements.",
              icon: "factory",
            },
            {
              title: "Deploy",
              text: "Put systems into operational environments where performance can be observed and improved.",
              icon: "drone",
            },
            {
              title: "Learn",
              text: "Use field experience and service signals to guide what should come next.",
              icon: "brain",
            },
          ]}
        />
      </SectionBlock>

      <SectionBlock
        eyebrow="From Lab to Field"
        title={
          <>
            Where engineering meets <em>real-world mission.</em>
          </>
        }
      >
        <div className="storyShowcaseGrid">
          <div className="storyShowcaseCard">
            <div className="storyShowcaseImgWrapper">
              <img src={teamDroneLab} alt="OJAS Engineering Lab and MILU Drone Port" />
              <span className="storyShowcaseTag">OJAS R&D LAB</span>
            </div>
            <div className="storyShowcaseContent">
              <small>SYSTEMS & HARDWARE INTEGRATION</small>
              <h3>MILU Drone Port & Systems Lab</h3>
              <p>
                Our core aerospace and software engineering team designing, assembling, and calibrating advanced autonomous drone platforms with edge AI integration.
              </p>
            </div>
          </div>

          <div className="storyShowcaseCard">
            <div className="storyShowcaseImgWrapper">
              <img src={teamFieldDeployment} alt="OJAS Drone Deployment in Mountain Terrain" />
              <span className="storyShowcaseTag">FIELD OPERATIONS</span>
            </div>
            <div className="storyShowcaseContent">
              <small>HIGH-ALTITUDE & TERRAIN TESTING</small>
              <h3>Ground Missions & Mountain Terrains</h3>
              <p>
                Validating performance in demanding real-world environments—from high-altitude mountain deployments to large-scale precision agricultural operations.
              </p>
            </div>
          </div>
        </div>
      </SectionBlock>

      <div className="aboutCinematic">
        <div>
          <small>OJAS / CINEMATIC STORY</small>
          <h2>Space → Earth → India → Field → Network</h2>
          <p>
            The deeper visual story can move from aerospace systems to the
            connected environments in which OJAS operates.
          </p>
        </div>
      </div>
      <SectionBlock
        eyebrow="What we bring together"
        title={
          <>
            Across disciplines, into <em>systems.</em>
          </>
        }
      >
        <DetailList
          items={[
            "Aerospace and UAV engineering",
            "Software and AI systems",
            "Sensing and geospatial intelligence",
            "Field operations and services",
            "Distributed infrastructure",
            "Applied research and emerging technology",
          ]}
        />
      </SectionBlock>
    </StandardPage>
  );
}
function ContactPage() {
  return (
    <StandardPage
      question="Start a conversation."
      title={
        <>
          Let's build <em>what comes next.</em>
        </>
      }
      description="For partnerships, technology conversations, projects, services or careers."
      image={ecosystemImage}
    >
      <section className="section contact contactModern">
        <ContactBlock />
      </section>
    </StandardPage>
  );
}

function Footer() {
  const cols = [
    [
      "EXPLORE",
      [
        ["Home", "/"],
        ["Sectors", "/sectors"],
        ["Solutions", "/solutions"],
        ["Services", "/services"],
      ],
    ],
    [
      "SYSTEM",
      [
        ["Technology", "/technology"],
        ["Infrastructure", "/milu-ai-network"],
        ["MILU AI", "/milu-ai"],
        ["Network", "/network"],
      ],
    ],
    [
      "COMPANY",
      [
        ["About", "/about"],
        ["Partners", "/partners"],
        ["News & Media", "/news"],
        ["Team", "/team"],
        ["Careers", "/careers"],
        ["Contact", "/contact"],
      ],
    ],
  ];
  return (
    <footer className="footer">
      <div className="footerTop">
        <div className="footerBrand">
          <div className="footerLogo">
            <img src={logo} alt="OJAS" />
          </div>
          <p>
            Engineering intelligent aerospace and field systems that turn
            information into action.
          </p>
        </div>
        {cols.map(([h, items]) => (
          <div key={String(h)}>
            <h4>{h as string}</h4>
            {(items as string[][]).map(([a, b]) => (
              <button key={b} onClick={() => navigate(b)}>
                {a}
              </button>
            ))}
          </div>
        ))}
        <div>
          <h4>FOLLOW US</h4>
          <div className="social">
            <button>in</button>
            <button>𝕏</button>
            <button>◎</button>
          </div>
        </div>
      </div>
      <div className="footerBottom">
        <span>© 2026 OJAS Aerospace. All rights reserved.</span>
        <span>Privacy Policy</span>
        <span>Terms of Use</span>
      </div>
    </footer>
  );
}

const SEO_MAP: Record<string, { title: string; description: string }> = {
  "/": {
    title: "OJAS Aerospace — Engineering the Intelligent Sky",
    description:
      "OJAS connects aerospace systems, AI and field infrastructure into a continuously sensing, learning and acting network.",
  },
  "/sectors": {
    title: "Sectors — Systems for Different Worlds",
    description:
      "Sectors describe the contexts in which OJAS applies aerospace systems, intelligence and field capability.",
  },
  "/solutions": {
    title: "Solutions — Intelligence for the Real World",
    description:
      "Six solution domains connect OJAS services and technology to concrete problems and outcomes.",
  },
  "/services": {
    title: "Services — From Field Work to Outcomes",
    description:
      "Explore practical, task-oriented services across agriculture, mapping, monitoring, logistics, emergency response, infrastructure, media and drone operations.",
  },
  "/technology": {
    title: "Technology — Built for the Field",
    description:
      "A coherent working stack across sensing, geospatial intelligence, AI, agriculture, autonomy and digital infrastructure.",
  },
  "/milu-ai": {
    title: "MILU AI — Intelligence That Connects",
    description:
      "MILU AI is OJAS's intelligence layer: connecting field signals, operational data and context so the network can understand, decide, act and learn.",
  },
  "/milu-ai-network": {
    title: "MILU AI Network — Where the Network Lives",
    description:
      "Distributed infrastructure that brings intelligence, field capability and connected operations closer to where work happens.",
  },
  "/network": {
    title: "Network — Connected Beyond the Screen",
    description:
      "The OJAS Network connects people, places, platforms, partners, customers and operations around the wider intelligence system.",
  },
  "/partners": {
    title: "Partners — Building the Network Together",
    description:
      "The OJAS ecosystem brings complementary organisations, capabilities and operating environments into a connected network.",
  },
  "/news": {
    title: "News, Stories & Media",
    description:
      "A structured editorial layer for company developments, field stories, technology updates, events and visual media.",
  },
  "/team": {
    title: "Team — The People Behind OJAS",
    description:
      "The multidisciplinary team building OJAS across technology, aerospace R&D, operations, business, design and field-focused systems.",
  },
  "/careers": {
    title: "Careers — Work Where Systems Meet Reality",
    description:
      "Careers across aerospace, intelligent systems, software, field technology, geospatial systems and business operations.",
  },
  "/about": {
    title: "About — Engineering What Comes Next",
    description:
      "OJAS is being shaped as a service-led systems company bringing aerospace, intelligent systems, infrastructure and applied R&D together.",
  },
  "/contact": {
    title: "Contact — Let's Build What Comes Next",
    description:
      "For partnerships, technology conversations, projects, services or careers.",
  },
};

const FAQ_MAP: Record<string, string> = {
  "/sectors": "Where does OJAS operate?",
  "/solutions": "What problems do we solve?",
  "/services": "What can OJAS do for you?",
  "/technology": "How do we make it possible?",
  "/milu-ai": "How does information become intelligence?",
  "/milu-ai-network": "Where does the network live?",
  "/network": "Who and what is connected?",
  "/partners": "Who do we build with?",
  "/news": "What is happening in the field?",
  "/team": "Who builds it?",
  "/careers": "Who wants to build it with us?",
  "/about": "What drives OJAS?",
};

function setPageSchema(schema: Record<string, unknown> | null) {
  const id = "page-schema";
  let el = document.getElementById(id) as HTMLScriptElement | null;
  if (!schema) {
    if (el) el.remove();
    return;
  }
  if (!el) {
    el = document.createElement("script");
    el.id = id;
    el.type = "application/ld+json";
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(schema);
}

function setMeta(selector: string, attr: string, value: string) {
  const el = document.querySelector(selector);
  if (el) el.setAttribute(attr, value);
}

function applySEO(rawTitle: string, description: string, path: string) {
  const title = `${rawTitle} | OJAS Aerospace`;
  const url = `https://www.ojasaerospace.com${path === "/" ? "/" : path}`;
  document.title = title;
  setMeta('meta[name="description"]', "content", description);
  setMeta('link[rel="canonical"]', "href", url);
  setMeta('meta[property="og:title"]', "content", title);
  setMeta('meta[property="og:description"]', "content", description);
  setMeta('meta[property="og:url"]', "content", url);
  setMeta('meta[name="twitter:title"]', "content", title);
  setMeta('meta[name="twitter:description"]', "content", description);
}

function useSEO(path: string) {
  useEffect(() => {
    const known = SEO_MAP[path];
    if (known) {
      applySEO(known.title, known.description, path);
      const q = FAQ_MAP[path];
      setPageSchema(
        q
          ? {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: [
              {
                "@type": "Question",
                name: q,
                acceptedAnswer: {
                  "@type": "Answer",
                  text: known.description,
                },
              },
            ],
          }
          : null
      );
      return;
    }
    const s = solutions.find((x) => solutionPath(x.title) === path);
    if (s) {
      applySEO(`${s.title} | Solutions`, s.text, path);
      setPageSchema({
        "@context": "https://schema.org",
        "@type": "Service",
        name: s.title,
        description: s.text,
        provider: {
          "@type": "Organization",
          name: "OJAS Aerospace",
          url: "https://www.ojasaerospace.com/",
        },
        areaServed: "IN",
      });
      return;
    }
    const svc = services.find((x) => servicePath(x.slug) === path);
    if (svc) {
      applySEO(`${svc.eyebrow} | Services`, svc.tagline, path);
      setPageSchema({
        "@context": "https://schema.org",
        "@type": "Service",
        name: svc.eyebrow,
        description: svc.tagline,
        provider: {
          "@type": "Organization",
          name: "OJAS Aerospace",
          url: "https://www.ojasaerospace.com/",
        },
        areaServed: "IN",
      });
      return;
    }
    applySEO(SEO_MAP["/"].title, SEO_MAP["/"].description, path);
    setPageSchema(null);
  }, [path]);
}

function Router() {
  const [path, setPath] = useState(location.pathname);
  useEffect(() => {
    const f = () => setPath(location.pathname);
    addEventListener("popstate", f);
    return () => removeEventListener("popstate", f);
  }, []);
  useSEO(path);
  if (path === "/" || path === "/home") return <Home />;
  if (path === "/sectors") return <SectorsPage />;
  if (path === "/solutions") return <SolutionsPage />;
  if (path === "/services") return <ServicesPage />;
  if (path === "/technology") return <TechnologyPage />;
  if (path === "/milu-ai") return <MiluPage />;
  if (path === "/milu-ai-network") return <InfrastructurePage />;
  if (path === "/network") return <NetworkPage />;
  if (path === "/partners") return <PartnersPage />;
  if (path === "/news") return <NewsPage />;
  if (path === "/team") return <TeamPage />;
  if (path === "/careers") return <CareersPage />;
  if (path === "/about") return <AboutPage />;
  if (path === "/contact") return <ContactPage />;
  const s = solutions.find((x) => solutionPath(x.title) === path);
  if (s) return <SolutionPage s={s} />;
  const svc = services.find((x) => servicePath(x.slug) === path);
  if (svc) return <ServiceDetailPage slug={svc.slug} />;
  return <Home />;
}
function FloatingCallButton() {
  return (
    <a
      href="tel:01354316767"
      className="floatCall"
      aria-label="Call OJAS Aerospace at 0135 431 6767"
    >
      <span className="floatCallRing r1" />
      <span className="floatCallRing r2" />
      <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7">
        <path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.5.6.6 0 1 .5 1 1V20c0 .6-.4 1-1 1C10.4 21 3 13.6 3 4.6c0-.6.4-1 1-1h3.4c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.5.1.4 0 .8-.2 1L6.6 10.8z" />
      </svg>
    </a>
  );
}

export default function App() {
  return (
    <div className="app">
      <SplashScreen />
      <FloatingCallButton />
      <Navbar />
      <main>
        <Router />
      </main>
      <Footer />
    </div>
  );
}

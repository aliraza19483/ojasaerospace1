import { ServiceGroup } from "../types";

export const serviceGroups: ServiceGroup[] = [
  {
    title: "Agriculture & Crop Care",
    intro:
      "Field-focused services for crop observation, intervention and agricultural intelligence.",
    icon: "leaf",
    items: [
      "Crop Health Monitoring",
      "Crop Scouting & Inspection",
      "Crop Disease & Stress Detection",
      "Precision Spraying",
      "Field Mapping",
      "Soil & Crop Intelligence",
      "Farm & Plantation Monitoring",
      "Agricultural Data & Advisory",
    ],
  },
  {
    title: "Survey, Mapping & Inspection",
    intro:
      "Spatial capture, measurement and documentation for land, assets and projects.",
    icon: "map",
    items: [
      "Land & Property Survey",
      "Topographic Survey",
      "Aerial Mapping",
      "Photogrammetry & 3D Mapping",
      "Construction Progress Monitoring",
      "Stockpile & Volume Measurement",
      "Terrain Assessment",
      "Asset Inspection",
    ],
  },
  {
    title: "Monitoring & Intelligence",
    intro:
      "Observation and analysis services for sites, environments, assets and remote areas.",
    icon: "eye",
    items: [
      "Site Monitoring",
      "Environmental Monitoring",
      "Surveillance & Reconnaissance",
      "Remote Area Monitoring",
      "Change Detection",
      "Geospatial Intelligence",
      "Real-Time Aerial Intelligence",
      "Asset Monitoring",
    ],
  },
  {
    title: "Logistics & Delivery",
    intro:
      "Aerial and remote delivery for medical, emergency, agricultural and industrial requirements.",
    icon: "truck",
    items: [
      "Medical Delivery",
      "Emergency Payload Delivery",
      "Agricultural / Industrial Delivery",
      "Remote-Area Delivery",
      "Time-Critical Logistics",
      "Last-Mile Aerial Logistics",
    ],
  },
  {
    title: "Disaster & Emergency Response",
    intro:
      "Rapid aerial and geospatial support when access, awareness and time are critical.",
    icon: "alert",
    items: [
      "Flood Assessment",
      "Search & Rescue Support",
      "Emergency Mapping",
      "Disaster Damage Assessment",
      "Landslide Assessment",
      "Rapid Situational Intelligence",
      "Emergency Reconnaissance",
    ],
  },
  {
    title: "Industrial & Infrastructure",
    intro:
      "Inspection, monitoring and documentation across critical industrial and utility assets.",
    icon: "factory",
    items: [
      "Infrastructure Inspection",
      "Construction Monitoring",
      "Power & Utility Inspection",
      "Industrial Site Inspection",
      "Mining & Quarry Monitoring",
      "Asset Inspection",
      "Progress Documentation",
      "Compliance Documentation",
    ],
  },
  {
    title: "Media, Events & Aerial Imaging",
    intro:
      "Aerial imagery and cinematic operations for events, property, tourism and brands.",
    icon: "camera",
    items: [
      "Aerial Photography",
      "Aerial Videography",
      "Weddings & Events",
      "Real Estate Imaging",
      "Tourism & Hospitality",
      "Promotional / Brand Content",
      "Cinematic Drone Operations",
    ],
  },
  {
    title: "Drone & Field Operations",
    intro:
      "Operational support for deploying, planning and executing specialized drone missions.",
    icon: "drone",
    items: [
      "Drone Deployment",
      "Mission Planning",
      "Pilot & Flight Operations",
      "Specialized Payload Operations",
      "Field Data Collection",
      "Multi-Drone Operations",
      "Long-Range Operations",
      "Custom Drone Missions",
    ],
  },
];

export const enableServices = [
  "Training & Certification",
  "UAV Support & Maintenance",
  "UAV Access — Acquire / Rent / Lease",
];

import { NewsItem } from "../types";
import ecosystemImage from "../assets/ecosystem.jpg";
import aboutImage from "../assets/about.jpg";
import technologyImage from "../assets/technology-impact.jpg";
import careersImage from "../assets/careers.jpg";

export const newsSeed: NewsItem[] = [
  ...[
    "Network architecture",
    "Service-led systems",
    "OJAS technology roadmap",
  ].map((title, i) => ({
    title,
    category: "News",
    date: `2026.0${i + 7}.0${i + 1}`,
    text: "OJAS platform content placeholder structured for future verified company updates.",
    image: ecosystemImage,
  })),
  ...[
    "Crop intelligence in the field",
    "Aerial mapping workflow",
    "Rapid situational awareness",
  ].map((title, i) => ({
    title,
    category: "Field Stories",
    date: `2026.0${i + 6}.1${i + 1}`,
    text: "Field-story placeholder ready to be replaced with a verified OJAS operation.",
    image: aboutImage,
  })),
  ...[
    "OJAS cinematic reel",
    "MILU AI visual system",
    "Aerial imaging showcase",
  ].map((title, i) => ({
    title,
    category: "Media",
    date: `2026.0${i + 5}.2${i + 1}`,
    text: "Media placeholder for future OJAS video, photography or visual assets.",
    image: technologyImage,
  })),
  ...[
    "Multispectral crop intelligence",
    "Geospatial processing pipeline",
    "AI decision intelligence",
  ].map((title, i) => ({
    title,
    category: "Technology",
    date: `2026.0${i + 4}.1${i + 2}`,
    text: "Technology editorial placeholder based on the current working stack.",
    image: technologyImage,
  })),
  ...[
    "Aerospace technology forum",
    "Field systems demonstration",
    "OJAS partner session",
  ].map((title, i) => ({
    title,
    category: "Events",
    date: `2026.0${i + 3}.2${i + 2}`,
    text: "Event placeholder ready for verified OJAS participation details.",
    image: careersImage,
  })),
];

export const networkNodes: [string, string, string][] = [
  [
    "MILU AI NETWORK",
    "The complete distributed intelligence architecture.",
    "network",
  ],
  ["MILU HUB", "A higher-level coordination and aggregation layer.", "globe"],
  [
    "MILU CENTRE",
    "A substantial operating environment for connected capabilities.",
    "factory",
  ],
  [
    "MILU STATION",
    "A local operational node bringing systems closer to the field.",
    "drone",
  ],
  [
    "MILU POINT",
    "A distributed edge presence where intelligence and services can reach the operating environment.",
    "signal",
  ],
];

export const partnersList: [string, string, string][] = [
  [
    "Technology",
    "Technology providers, platforms, sensing systems and digital infrastructure that strengthen the OJAS stack.",
    "cpu",
  ],
  [
    "Agriculture & Industry",
    "Domain organisations that connect OJAS capabilities to real operational environments.",
    "factory",
  ],
  [
    "Institutional",
    "Public-sector, research and institutional relationships supporting broader deployment and capability building.",
    "book",
  ],
  [
    "Deployment",
    "Local operators and implementation relationships that help services reach the field.",
    "drone",
  ],
  [
    "Strategic",
    "Long-term relationships around research, expansion, investment and ecosystem development.",
    "target",
  ],
];

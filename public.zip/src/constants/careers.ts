import { CareerItem } from "../types";

export const careerSeed: CareerItem[] = [
  "Aerospace Engineering",
  "AI & Software",
  "Field Operations",
  "Business Systems",
  "Geospatial Technology",
  "Agriculture Technology",
  "Mission Operations",
  "Product & Platform",
].map((x, i) => ({
  title: x,
  text: "Role placeholder. Replace with an active OJAS position when hiring data is available.",
  icon: ["cpu", "brain", "drone", "network", "map", "leaf", "route", "grid"][i],
}));

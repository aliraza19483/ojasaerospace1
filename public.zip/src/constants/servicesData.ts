// ─────────────────────────────────────────────────────────────────────────
// OJAS AEROSPACE — SERVICES CONTENT (DEMO)
// 4 core services: Drone Sale · Repair & Maintenance · Rental · Training
//
// STATUS: Placeholder/demo content + placeholder image paths.
// Replace `image:` paths with real assets once available (drop files into
// src/assets/services/<service>/... and update the import at the top of
// whichever page component consumes this file).
//
// ⚠ TWO FACTS ARE STILL UNCONFIRMED — search "TODO CONFIRM" below:
//   1) Drone Sale — does OJAS manufacture, resell third-party brands, or both?
//   2) Drone Training — is OJAS a DGCA-certified RPTO (Remote Pilot Training
//      Organisation)? Do NOT publish a certification claim until confirmed —
//      wrong certification claims are a legal/compliance risk.
// ─────────────────────────────────────────────────────────────────────────

export type FAQ = { q: string; a: string };

export type ProcessStep = {
  step: string;       // "01"
  title: string;
  description: string;
};

export type Offering = {
  title: string;
  description: string;
  // Optional spec sheet — used by Drone Sale categories
  specs?: { label: string; value: string }[];
  image?: string;
};

export type ServiceContent = {
  slug: string;
  icon: string; // matches existing Icon component glyph keys used elsewhere in the codebase
  hero: {
    eyebrow: string;
    title: string;
    tagline: string;
    ctaPrimary: string;
    ctaSecondary: string;
    image: string;
  };
  includes: {
    heading: string;
    intro: string;
    items: Offering[];
  };
  howItWorks: {
    heading: string;
    steps: ProcessStep[];
  };
  whyOjas: {
    heading: string;
    points: { title: string; description: string }[];
  };
  pricing: {
    heading: string;
    note: string;
    cta: string;
  };
  faq: FAQ[];
  cta: {
    title: string;
    subtitle: string;
    primaryLabel: string;
    secondaryLabel: string;
  };
};

export const services: ServiceContent[] = [
  // ── 1. DRONE SALE ─────────────────────────────────────────────────────
  {
    slug: "drone-sale",
    icon: "drone",
    hero: {
      eyebrow: "Drone Sale",
      title: "The right drone, built for the work it needs to do.",
      tagline:
        "Agriculture, mapping, surveillance and custom platforms — supplied, configured and registered, ready for the field.",
      ctaPrimary: "Request a Quote",
      ctaSecondary: "Book a Demo Flight",
      image: "/assets/services/drone-sale/hero.jpg", // TODO: replace with real hero photo
    },
    includes: {
      heading: "Choose by category",
      intro:
        "Every platform is matched to its job — payload, endurance and sensors selected for the environment it will operate in.",
      items: [
        {
          title: "Agriculture Spraying Drones",
          description:
            "High-payload spraying platforms for precision input application across crop fields.",
          specs: [
            { label: "Payload", value: "10 – 40 L tank" },
            { label: "Flight Time", value: "18 – 25 min / cycle" },
            { label: "Range", value: "Up to 2 km (visual line-of-sight)" },
            { label: "Sensor", value: "RTK-GPS + terrain-follow radar" },
          ],
          image: "/assets/services/drone-sale/agri-spray.jpg",
        },
        {
          title: "Mapping & Survey Drones",
          description:
            "Fixed-wing and multirotor platforms for orthomosaics, topographic survey and land digitisation.",
          specs: [
            { label: "Payload", value: "Up to 1.5 kg camera/LiDAR" },
            { label: "Flight Time", value: "35 – 55 min" },
            { label: "Range", value: "Up to 5 km" },
            { label: "Sensor", value: "RGB / multispectral / LiDAR" },
          ],
          image: "/assets/services/drone-sale/mapping.jpg",
        },
        {
          title: "Surveillance & Inspection Drones",
          description:
            "Stabilised, low-light-capable platforms for perimeter monitoring and infrastructure inspection.",
          specs: [
            { label: "Payload", value: "Gimbal camera + thermal (optional)" },
            { label: "Flight Time", value: "28 – 40 min" },
            { label: "Range", value: "Up to 7 km" },
            { label: "Sensor", value: "EO/IR gimbal, zoom optics" },
          ],
          image: "/assets/services/drone-sale/surveillance.jpg",
        },
        {
          title: "Custom & Enterprise-Built Drones",
          description:
            // TODO CONFIRM: confirm whether OJAS designs/manufactures in-house
            // vs. configures third-party airframes, then adjust this line.
            "Purpose-built configurations for non-standard payloads, mission profiles or enterprise fleets.",
          specs: [
            { label: "Payload", value: "Mission-specific" },
            { label: "Flight Time", value: "Mission-specific" },
            { label: "Range", value: "Mission-specific" },
            { label: "Sensor", value: "Configurable" },
          ],
          image: "/assets/services/drone-sale/custom.jpg",
        },
      ],
    },
    howItWorks: {
      heading: "From enquiry to delivery",
      steps: [
        { step: "01", title: "Enquiry", description: "Tell us the use case, budget and site conditions." },
        { step: "02", title: "Assessment", description: "We recommend a platform and configuration to match the job." },
        { step: "03", title: "Registration Support", description: "Assistance with DGCA registration and UIN so the drone is legally airworthy before it flies." },
        { step: "04", title: "Delivery & Handover", description: "Platform delivered, tested and handed over with a orientation flight." },
      ],
    },
    whyOjas: {
      heading: "Why buy through OJAS",
      points: [
        { title: "DGCA Registration Assistance", description: "We help you through UIN registration so your drone is compliant from day one." },
        { title: "Warranty & After-Sales", description: "Every platform ships with warranty cover and ongoing service support." },
        { title: "Field-Tested Configurations", description: "Platforms are configured and tested for real operating conditions before delivery." },
        { title: "Financing on Request", description: "EMI / financing options available for eligible buyers." }, // TODO: confirm if financing is actually offered — remove if not
      ],
    },
    pricing: {
      heading: "Pricing",
      note: "Pricing depends on platform, payload and configuration.",
      cta: "Get a Custom Quote",
    },
    faq: [
      { q: "Do you help with DGCA registration?", a: "Yes — we guide you through UIN registration so the drone is legally cleared to fly before delivery." },
      { q: "Can I get a demo before buying?", a: "Yes, demo flights can be arranged at our facility or, where feasible, on-site." },
      { q: "Is financing available?", a: "EMI options are available for eligible buyers on request — ask our team for current terms." },
      { q: "What's covered under warranty?", a: "Standard warranty covers manufacturing defects and core hardware; ask for full terms specific to your platform." },
    ],
    cta: {
      title: "Ready to find the right drone for your operation?",
      subtitle: "Tell us what you're trying to do — we'll recommend a platform and configuration.",
      primaryLabel: "Request a Quote",
      secondaryLabel: "Book a Demo Flight",
    },
  },

  // ── 2. DRONE REPAIR & MAINTENANCE ───────────────────────────────────────
  {
    slug: "drone-repair-maintenance",
    icon: "wrench",
    hero: {
      eyebrow: "Repair & Maintenance",
      title: "Keep your fleet flying, not grounded.",
      tagline:
        "Certified technicians, genuine parts and fast turnaround — for hardware, cameras, batteries and firmware.",
      ctaPrimary: "Book a Repair",
      ctaSecondary: "Request an AMC",
      image: "/assets/services/repair/hero.jpg",
    },
    includes: {
      heading: "What we repair",
      intro: "From a single fix to full fleet upkeep — covered under one roof.",
      items: [
        { title: "Hardware Repair", description: "Motors, ESCs, frames and propellers — diagnosed and replaced with genuine parts.", image: "/assets/services/repair/hardware.jpg" },
        { title: "Camera & Gimbal Repair", description: "Calibration and repair of gimbal stabilisation and imaging payloads.", image: "/assets/services/repair/gimbal.jpg" },
        { title: "Battery Health & Replacement", description: "Battery diagnostics, cell health checks and safe replacement.", image: "/assets/services/repair/battery.jpg" },
        { title: "Firmware & Software Issues", description: "Firmware updates, calibration resets and software troubleshooting.", image: "/assets/services/repair/firmware.jpg" },
      ],
    },
    howItWorks: {
      heading: "How servicing works",
      steps: [
        { step: "01", title: "Book", description: "Log the issue online or over call — pickup or drop-off, your choice." },
        { step: "02", title: "Diagnose", description: "Certified technicians run a full diagnostic within 48 hours." },
        { step: "03", title: "Repair", description: "Genuine parts used; you're informed before any paid replacement." },
        { step: "04", title: "Return & Test Flight", description: "Unit tested before it's returned to you, ready to fly." },
      ],
    },
    whyOjas: {
      heading: "Why service with OJAS",
      points: [
        { title: "Certified Technicians", description: "Every repair is handled by trained, certified hands." },
        { title: "Genuine Spare Parts", description: "No third-party substitutes — original components only." },
        { title: "48-Hour Diagnostic Promise", description: "You get a clear diagnosis and quote within 48 hours." },
        { title: "Pickup & Drop Available", description: "On-site or courier pickup for eligible locations." },
      ],
    },
    pricing: {
      heading: "AMC Plans",
      note: "Annual Maintenance Contracts available — fixed-cost coverage instead of pay-per-repair.",
      cta: "Get a Custom Quote",
    },
    faq: [
      { q: "How long does a repair take?", a: "Most repairs are diagnosed within 48 hours; turnaround for the fix itself depends on parts availability." },
      { q: "What is an AMC?", a: "An Annual Maintenance Contract covers scheduled servicing and priority repairs for a fixed annual cost." },
      { q: "Do you offer pickup and drop?", a: "Yes, for eligible locations — ask our team when booking." },
      { q: "Are spare parts genuine?", a: "Yes, we use only genuine or OEM-approved parts for every repair." },
    ],
    cta: {
      title: "Don't let downtime ground your operation.",
      subtitle: "Book a repair or set up an AMC and keep your fleet field-ready.",
      primaryLabel: "Book a Repair",
      secondaryLabel: "Request an AMC",
    },
  },

  // ── 3. DRONE RENTAL ─────────────────────────────────────────────────────
  {
    slug: "drone-rental",
    icon: "route",
    hero: {
      eyebrow: "Drone Rental",
      title: "Access the right drone, only when you need it.",
      tagline:
        "Daily, weekly, monthly or seasonal rentals — with or without a pilot, delivered where you operate.",
      ctaPrimary: "Check Availability",
      ctaSecondary: "Get a Rental Quote",
      image: "/assets/services/rental/hero.jpg",
    },
    includes: {
      heading: "Rental categories",
      intro: "Pick the platform for the job — and the duration that fits it.",
      items: [
        { title: "Agri Spraying Drone Rental", description: "Season-based rentals for spraying operations during peak crop cycles.", image: "/assets/services/rental/agri.jpg" },
        { title: "Survey & Mapping Drone Rental", description: "Short-term access to mapping platforms for one-off or periodic surveys.", image: "/assets/services/rental/survey.jpg" },
        { title: "Event & Media Drone Rental", description: "Camera-equipped drones for event coverage and media production.", image: "/assets/services/rental/event.jpg" },
        { title: "Industrial Inspection Drone Rental", description: "Inspection-grade platforms for infrastructure and facility checks.", image: "/assets/services/rental/inspection.jpg" },
      ],
    },
    howItWorks: {
      heading: "How rental works",
      steps: [
        { step: "01", title: "Choose Duration", description: "Daily, weekly, monthly or full-season — whatever the job needs." },
        { step: "02", title: "Pilot Option", description: "Take the drone self-operate, or add an OJAS pilot." },
        { step: "03", title: "Delivery & Setup", description: "Delivered and set up at your site within the service area." },
        { step: "04", title: "Return", description: "Simple pickup at the end of the rental period." },
      ],
    },
    whyOjas: {
      heading: "Why rent with OJAS",
      points: [
        { title: "Pilot-Included or Self-Operate", description: "Choose the option that fits your team's capability." },
        { title: "Insurance Coverage", description: "Damage coverage terms included with every rental agreement." },
        { title: "On-Site Delivery & Setup", description: "We deliver and set up within our service area." },
        { title: "Transparent Deposit Terms", description: "Clear security deposit terms, explained upfront." },
      ],
    },
    pricing: {
      heading: "Rental Plans",
      note: "Rates vary by platform, duration and pilot option.",
      cta: "Get a Rental Quote",
    },
    faq: [
      { q: "Can I rent without a pilot?", a: "Yes — self-operate rentals are available if you have a qualified operator." },
      { q: "Is insurance included?", a: "Yes, damage coverage terms are included; full terms are shared at booking." },
      { q: "What's the minimum rental period?", a: "Daily rentals are available; longer terms get better rates." },
      { q: "Do you deliver to the site?", a: "Yes, within our service area — confirm coverage for your location when booking." },
    ],
    cta: {
      title: "Get the drone you need, exactly when you need it.",
      subtitle: "Check availability for your location and dates.",
      primaryLabel: "Check Availability",
      secondaryLabel: "Get a Rental Quote",
    },
  },

  // ── 4. DRONE TRAINING ───────────────────────────────────────────────────
  {
    slug: "drone-training",
    icon: "network",
    hero: {
      eyebrow: "Drone Training",
      title: "Learn to fly. Get certified. Get to work.",
      tagline:
        "Structured, instructor-led training — from first flight to professional operation.",
      ctaPrimary: "Enroll Now",
      ctaSecondary: "Request Batch Schedule",
      image: "/assets/services/training/hero.jpg",
    },
    includes: {
      heading: "Courses offered",
      intro: "Programmes for individuals, operators and organisations.",
      items: [
        { title: "Basic / Beginner Drone Flying", description: "Foundational flight training for first-time pilots.", image: "/assets/services/training/basic.jpg" },
        {
          title: "Remote Pilot Certificate Course",
          // TODO CONFIRM RPTO STATUS before publishing. If OJAS is NOT a
          // DGCA-certified RPTO, remove any certification claim and instead
          // describe this as prep/coordination support, or remove the course
          // entirely until certification status is confirmed.
          description: "Structured preparation for remote pilot certification, covering theory and practical requirements.",
          image: "/assets/services/training/rpc.jpg",
        },
        { title: "Agri-Drone Operator Certification", description: "Focused training for agricultural spraying and survey operations.", image: "/assets/services/training/agri.jpg" },
        { title: "Corporate / Institutional Batch Training", description: "Custom batch programmes for organisations building in-house drone capability.", image: "/assets/services/training/corporate.jpg" },
      ],
    },
    howItWorks: {
      heading: "Course structure",
      steps: [
        { step: "01", title: "Theory", description: "Classroom sessions covering regulations, safety and flight fundamentals." },
        { step: "02", title: "Simulator", description: "Simulator-based practice before real flight time." },
        { step: "03", title: "Practical Flying Hours", description: "Supervised flight hours to build real operating skill." },
        { step: "04", title: "Certification", description: "Certificate issued on successful completion of the programme." },
      ],
    },
    whyOjas: {
      heading: "Why train with OJAS",
      points: [
        { title: "Instructor-Led Programme", description: "Small batches, hands-on instruction throughout." },
        { title: "Theory + Simulator + Practical", description: "A complete path from classroom to real flight." },
        { title: "Certificate on Completion", description: "Documented proof of training completion." },
        { title: "Placement Assistance", description: "Guidance connecting trained pilots to field opportunities." }, // TODO: confirm placement assistance is actually offered
      ],
    },
    pricing: {
      heading: "Batches & Fees",
      note: "Fees vary by course and batch size.",
      cta: "Request Batch Schedule",
    },
    faq: [
      { q: "Do I need prior experience?", a: "No — the beginner course assumes no prior flying experience." },
      { q: "How long is the course?", a: "Duration varies by course; ask our team for the current schedule." },
      { q: "Is certification provided?", a: "A certificate of completion is issued at the end of every programme." },
      { q: "Do you offer batch training for companies?", a: "Yes — corporate and institutional batches can be arranged on request." },
    ],
    cta: {
      title: "Start your journey to becoming a certified drone pilot.",
      subtitle: "Batches are forming — reserve your seat.",
      primaryLabel: "Enroll Now",
      secondaryLabel: "Request Batch Schedule",
    },
  },
];
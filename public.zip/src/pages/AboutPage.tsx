import React from "react";
import aboutImage from "../assets/about.jpg";
import teamDroneLab from "../assets/team-drone-lab.jpg";
import teamFieldDeployment from "../assets/team-field-deployment.jpg";
import { StandardPage } from "../components/ui/StandardPage";
import { SectionBlock } from "../components/ui/SectionBlock";
import { IconCards } from "../components/ui/IconCards";
import { DetailList } from "../components/ui/DetailList";

export function AboutPage() {
  return (
    <StandardPage
      question="What drives OJAS?"
      title={
        <>
          Engineering <em>what comes next.</em>
        </>
      }
      description="OJAS is being shaped as a service-led systems company bringing aerospace, intelligent systems, infrastructure and applied R&D together."
      image={aboutImage}
    >
      <SectionBlock
        eyebrow="The OJAS idea"
        title={
          <>
            Service-led. Technology-driven. <em>Intelligence-connected.</em>
          </>
        }
      >
        <p className="wideLead">
          Real customer and field requirements generate service work. Service
          work generates information and signals. Those signals can improve
          decision-making and help guide technology development and research
          direction — creating a feedback loop that improves future services.
        </p>
        <IconCards
          items={[
            {
              title: "Build",
              text: "Develop and integrate aerospace, software, sensing and field systems around real requirements.",
              icon: "factory",
            },
            {
              title: "Deploy",
              text: "Put systems into operational environments where performance can be observed and improved.",
              icon: "drone",
            },
            {
              title: "Learn",
              text: "Use field experience and service signals to guide what should come next.",
              icon: "brain",
            },
          ]}
        />
      </SectionBlock>

      <SectionBlock
        eyebrow="From Lab to Field"
        title={
          <>
            Where engineering meets <em>real-world mission.</em>
          </>
        }
      >
        <div className="storyShowcaseGrid">
          <div className="storyShowcaseCard">
            <div className="storyShowcaseImgWrapper">
              <img src={teamDroneLab} alt="OJAS Engineering Lab and MILU Drone Port" />
              <span className="storyShowcaseTag">OJAS R&D LAB</span>
            </div>
            <div className="storyShowcaseContent">
              <small>SYSTEMS & HARDWARE INTEGRATION</small>
              <h3>MILU Drone Port & Systems Lab</h3>
              <p>
                Our core aerospace and software engineering team designing, assembling, and calibrating advanced autonomous drone platforms with edge AI integration.
              </p>
            </div>
          </div>

          <div className="storyShowcaseCard">
            <div className="storyShowcaseImgWrapper">
              <img src={teamFieldDeployment} alt="OJAS Drone Deployment in Mountain Terrain" />
              <span className="storyShowcaseTag">FIELD OPERATIONS</span>
            </div>
            <div className="storyShowcaseContent">
              <small>HIGH-ALTITUDE & TERRAIN TESTING</small>
              <h3>Ground Missions & Mountain Terrains</h3>
              <p>
                Validating performance in demanding real-world environments—from high-altitude mountain deployments to large-scale precision agricultural operations.
              </p>
            </div>
          </div>
        </div>
      </SectionBlock>

      <div className="aboutCinematic">
        <div>
          <small>OJAS / CINEMATIC STORY</small>
          <h2>Space → Earth → India → Field → Network</h2>
          <p>
            The deeper visual story can move from aerospace systems to the
            connected environments in which OJAS operates.
          </p>
        </div>
      </div>
      <SectionBlock
        eyebrow="What we bring together"
        title={
          <>
            Across disciplines, into <em>systems.</em>
          </>
        }
      >
        <DetailList
          items={[
            "Aerospace and UAV engineering",
            "Software and AI systems",
            "Sensing and geospatial intelligence",
            "Field operations and services",
            "Distributed infrastructure",
            "Applied research and emerging technology",
          ]}
        />
      </SectionBlock>
    </StandardPage>
  );
}

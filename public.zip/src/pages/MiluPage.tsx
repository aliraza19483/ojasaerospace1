import React from "react";
import miluImage from "../assets/milu-ai.webp";
import { navigate } from "../utils/navigation";
import { StandardPage } from "../components/ui/StandardPage";
import { SectionBlock } from "../components/ui/SectionBlock";
import { Icon } from "../components/ui/Icon";

export function MiluPage() {
  const steps = [
    [
      "SENSE",
      "Collect signals from the field and connected systems.",
      "signal",
    ],
    ["UNDERSTAND", "Fuse information and interpret it in context.", "brain"],
    ["PREDICT", "Identify likely changes, risks and opportunities.", "target"],
    [
      "DECIDE",
      "Turn intelligence into clear priorities and recommendations.",
      "cpu",
    ],
    [
      "ACT",
      "Connect decisions to people, services and operational systems.",
      "bolt",
    ],
    [
      "LEARN",
      "Feed outcomes back into the network, services and R&D.",
      "network",
    ],
  ];

  return (
    <StandardPage
      question="How does information become intelligence?"
      title={
        <>
          Intelligence <em>that connects.</em>
        </>
      }
      description="MILU AI is OJAS's intelligence layer: connecting field signals, operational data and context so the network can understand, decide, act and learn."
      image={miluImage}
    >
      <SectionBlock
        eyebrow="How MILU thinks"
        title={
          <>
            Sense → understand → <em>act.</em>
          </>
        }
      >
        <p className="wideLead">
          MILU is not a chatbot or a standalone dashboard. It is an operational
          intelligence layer that connects distributed information to decisions
          and then back to real-world action.
        </p>
        <div className="miluAiFlow">
          {steps.map(([a, b, ic], i) => (
            <React.Fragment key={a}>
              <article>
                <div className="iconBubble">
                  <Icon name={ic} />
                </div>
                <small>{String(i + 1).padStart(2, "0")}</small>
                <h3>{a}</h3>
                <p>{b}</p>
              </article>
              {i < steps.length - 1 && <span className="miluArrow">→</span>}
            </React.Fragment>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="What feeds MILU"
        title={
          <>
            Signals from across the <em>network.</em>
          </>
        }
      >
        <div className="miluSourceGrid">
          <article>
            <Icon name="drone" />
            <h3>Field & aerial data</h3>
            <p>
              UAVs, sensors, imagery and observations from operations in the
              physical world.
            </p>
          </article>
          <article>
            <Icon name="map" />
            <h3>Spatial context</h3>
            <p>
              Geospatial, satellite, weather and environmental information that
              explains where and when things are changing.
            </p>
          </article>
          <article>
            <Icon name="cpu" />
            <h3>Operational systems</h3>
            <p>
              Service activity, CRM/ERP signals, workflows and other business or
              operational information.
            </p>
          </article>
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="The feedback loop"
        title={
          <>
            Services learn. The system <em>improves.</em>
          </>
        }
      >
        <div className="miluFeedback">
          <b>SERVICE</b>
          <span>→</span>
          <b>DATA</b>
          <span>→</span>
          <b>INTELLIGENCE</b>
          <span>→</span>
          <b>DECISION</b>
          <span>→</span>
          <b>ACTION</b>
          <span>→</span>
          <b>OUTCOME</b>
          <span>↺</span>
        </div>
        <p className="wideLead">
          Outcomes and feedback can improve future service delivery, guide
          decision-making and help direct OJAS technology development and
          research.
        </p>
      </SectionBlock>
      <button
        className="networkBanner"
        onClick={() => navigate("/milu-ai-network")}
      >
        EXPLORE MILU AI NETWORK →
      </button>
    </StandardPage>
  );
}

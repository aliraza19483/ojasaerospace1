import React from "react";
import careersImage from "../assets/careers.jpg";
import { serviceGroups, enableServices } from "../constants/services";
import { navigate, servicePath } from "../utils/navigation";
import { StandardPage } from "../components/ui/StandardPage";
import { SectionBlock } from "../components/ui/SectionBlock";
import { DetailList } from "../components/ui/DetailList";
import { Icon } from "../components/ui/Icon";

export function ServicesPage() {
  return (
    <StandardPage
      question="What can OJAS do for you?"
      title={
        <>
          Services from field work <em>to outcomes.</em>
        </>
      }
      description="Explore practical, task-oriented services across agriculture, mapping, monitoring, logistics, emergency response, infrastructure, media and drone operations."
      image={careersImage}
    >
      <SectionBlock
        eyebrow="Service catalogue"
        title={
          <>
            Start with the <em>task.</em>
          </>
        }
      >
        <div className="serviceDirectory">
          {serviceGroups.map((g, i) => (
            <article key={g.title}>
              <div className="serviceGroupHead">
                <div className="iconBubble">
                  <Icon name={g.icon} />
                </div>
                <div>
                  <small>0{i + 1}</small>
                  <h3>{g.title}</h3>
                  <p>{g.intro}</p>
                </div>
              </div>
              <div className="servicePills">
                {g.items.map((x) => (
                  <button key={x} onClick={() => navigate(servicePath(x))}>
                    {x}
                    <span>↗</span>
                  </button>
                ))}
              </div>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Additional ways to engage"
        title={
          <>
            Enable the <em>operation.</em>
          </>
        }
      >
        <DetailList items={enableServices} />
      </SectionBlock>
    </StandardPage>
  );
}

import React from "react";
import ecosystemImage from "../assets/ecosystem.jpg";
import { StandardPage } from "../components/ui/StandardPage";
import { SectionBlock } from "../components/ui/SectionBlock";
import { IconCards } from "../components/ui/IconCards";
import { Icon } from "../components/ui/Icon";

export function NetworkPage() {
  return (
    <StandardPage
      question="Who and what is connected?"
      title={
        <>
          A network built <em>beyond the screen.</em>
        </>
      }
      description="The OJAS Network connects people, places, platforms, partners, customers and operations around the wider intelligence system."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="Network layers"
        title={
          <>
            People. Places. Systems. <em>Operations.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "People",
              text: "Engineers, operators, field teams, customers, partners and domain contributors.",
              icon: "network",
            },
            {
              title: "Places",
              text: "MILU infrastructure and the environments in which services and operations occur.",
              icon: "globe",
            },
            {
              title: "Platforms",
              text: "UAVs, sensors, software and other systems connected to missions.",
              icon: "drone",
            },
            {
              title: "Operations",
              text: "Services and field workflows that turn capability into outcomes.",
              icon: "route",
            },
          ]}
        />
      </SectionBlock>
      <SectionBlock
        eyebrow="The national view"
        title={
          <>
            A distributed <em>India network.</em>
          </>
        }
      >
        <div className="networkMapPlaceholder">
          <div className="mapGlow">INDIA</div>
          <span className="node n1" />
          <span className="node n2" />
          <span className="node n3" />
          <span className="node n4" />
          <span className="node n5" />
          <p>
            Interactive network mapping can be populated with verified OJAS
            nodes, capabilities and status as deployment data becomes available.
          </p>
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="Infrastructure relationship"
        title={
          <>
            Structure → connection → <em>action.</em>
          </>
        }
      >
        <div className="feedbackLoop">
          <div>
            <Icon name="factory" />
            <b>Infrastructure</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="network" />
            <b>Network</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="brain" />
            <b>MILU AI</b>
          </div>
          <span>→</span>
          <div>
            <Icon name="drone" />
            <b>Services</b>
          </div>
        </div>
      </SectionBlock>
    </StandardPage>
  );
}

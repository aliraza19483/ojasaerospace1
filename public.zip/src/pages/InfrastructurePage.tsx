import React from "react";
import ecosystemImage from "../assets/ecosystem.jpg";
import { networkNodes } from "../constants/network";
import { navigate } from "../utils/navigation";
import { StandardPage } from "../components/ui/StandardPage";
import { SectionBlock } from "../components/ui/SectionBlock";
import { IconCards } from "../components/ui/IconCards";
import { Icon } from "../components/ui/Icon";

export function InfrastructurePage() {
  return (
    <StandardPage
      question="Where does the network live?"
      title={
        <>
          MILU AI <em>Network.</em>
        </>
      }
      description="Distributed infrastructure that brings intelligence, field capability and connected operations closer to where work happens."
      image={ecosystemImage}
    >
      <SectionBlock
        eyebrow="The infrastructure hierarchy"
        title={
          <>
            Intelligence across <em>distance.</em>
          </>
        }
      >
        <div className="networkDetailStack">
          {networkNodes.map(([x, d, ic], i) => (
            <article key={x}>
              <div className="iconBubble">
                <Icon name={ic} />
              </div>
              <small>0{i + 1}</small>
              <h2>{x}</h2>
              <p>{d}</p>
            </article>
          ))}
        </div>
      </SectionBlock>
      <SectionBlock
        eyebrow="What infrastructure enables"
        title={
          <>
            Closer to the <em>operation.</em>
          </>
        }
      >
        <IconCards
          items={[
            {
              title: "Drone operations",
              text: "Operational environments for deployment, mission preparation and field support.",
              icon: "drone",
            },
            {
              title: "Data & connectivity",
              text: "Connected infrastructure can support data collection, transfer and local context.",
              icon: "signal",
            },
            {
              title: "Training & support",
              text: "Capability can be supported through training, maintenance and operational assistance.",
              icon: "wrench",
            },
            {
              title: "Service delivery",
              text: "Distributed nodes can bring customer-facing services closer to operating environments.",
              icon: "bolt",
            },
          ]}
        />
      </SectionBlock>
      <button className="largeCta" onClick={() => navigate("/network")}>
        EXPLORE THE NETWORK →
      </button>
    </StandardPage>
  );
}

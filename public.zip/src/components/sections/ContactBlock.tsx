import React from "react";
import { Eyebrow } from "../ui/Eyebrow";

export function ContactBlock() {
  return (
    <div className="contactLayout">
      <div className="contactPitch">
        <Eyebrow>CONTACT</Eyebrow>
        <h2>
          Let's build <em>what comes next.</em>
        </h2>
        <p>
          For partnerships, technology conversations, projects, services or
          careers.
        </p>
        <div className="contactDetails">
          <div>
            <small>EMAIL</small>
            <a href="mailto:info@ojasspace.com">info@ojasspace.com</a>
          </div>
          <div>
            <small>OFFICE</small>
            <span>Imperial Heights, Dehradun, Uttarakhand</span>
          </div>
        </div>
      </div>
      <form
        className="contactForm"
        onSubmit={(e) => {
          e.preventDefault();
          alert("Your enquiry is ready to be connected to OJAS.");
        }}
      >
        <label>
          NAME
          <input required placeholder="Your name" />
        </label>
        <label>
          EMAIL
          <input required type="email" placeholder="you@company.com" />
        </label>
        <label>
          WHAT ARE YOU EXPLORING?
          <textarea required placeholder="Tell us briefly..." />
        </label>
        <button className="sendEnquiry">
          SEND ENQUIRY <span>↗</span>
        </button>
      </form>
    </div>
  );
}

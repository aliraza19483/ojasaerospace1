import React, { useEffect, useRef } from "react";
import { Eyebrow } from "../ui/Eyebrow";
import heroVideo from "../../assets/main_4.mp4";
import { navigate } from "../../utils/navigation";

export function CinematicHero() {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.defaultMuted = true;
      videoRef.current.muted = true;
      videoRef.current.play().catch(() => { });
    }
  }, []);

  return (
    <section id="home" className="cinematic heroVideoSection">
      <video
        ref={videoRef}
        src={heroVideo}
        className="heroBgVideo"
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
      />


      <div className="particleCopy">
        <Eyebrow>OJAS AEROSPACE</Eyebrow>

        <h1>
          Building the
          <br />
          <em>Intelligent Network.</em>
        </h1>

        <p>
          OJAS connects aerospace systems, AI and field infrastructure into a
          continuously sensing, learning and acting network.
        </p>

        <div className="actions">
          <button
            className="btn goldBtn"
            onClick={() => navigate("/solutions")}
          >
            ◉ &nbsp; EXPLORE SOLUTIONS <b>↗</b>
          </button>
          <button
            className="btn outlineBtn"
            onClick={() => navigate("/about")}
          >
            OUR STORY <b>→</b>
          </button>
        </div>
      </div>

      <div className="heroTelemetryBadge">
        <small>SYSTEM STATUS</small>
        <b>24 ACTIVE NODES</b>
        <span>CONNECTED SENSING NETWORK</span>
      </div>
    </section>
  );
}

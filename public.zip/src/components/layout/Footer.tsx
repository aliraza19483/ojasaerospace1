import React from "react";
import logo from "../../assets/logo-gold.png";
import { navigate } from "../../utils/navigation";
import { MobileFooter } from "./MobileFooter";

export function Footer() {
  const cols: [string, [string, string][]][] = [
    [
      "EXPLORE",
      [
        ["Home", "/"],
        ["Sectors", "/sectors"],
        ["Services", "/services"],
      ],
    ],
    [
      "SYSTEM",
      [
        ["Technology", "/technology"],
        ["Infrastructure", "/milu-ai-network"],
        ["MILU AI", "/milu-ai"],
        ["Network", "/network"],
      ],
    ],
    [
      "COMPANY",
      [
        ["About", "/about"],
        ["Partners", "/partners"],
        ["News & Media", "/news"],
        ["Team", "/team"],
        ["Careers", "/careers"],
        ["Contact", "/contact"],
      ],
    ],
  ];

  return (
    <>
      <footer className="footer">
        <div className="footerTop">
          <div className="footerBrand">
            <div className="footerLogo">
              <img src={logo} alt="OJAS" />
            </div>
            <p>
              Engineering intelligent aerospace and field systems that turn
              information into action.
            </p>
          </div>
          {cols.map(([h, items]) => (
            <div key={h}>
              <h4>{h}</h4>
              {items.map(([a, b]) => (
                <button key={b} onClick={() => navigate(b)}>
                  {a}
                </button>
              ))}
            </div>
          ))}
          <div className="footerContact">
            <h4>COMMAND HQ</h4>
            <ul className="footerContactList">
              <li className="footerContactItem">
                <span className="footerContactIcon">📍</span>
                <span>
                  Office 9, Ground Floor, Commercial Building, Imperial Heights
                </span>
              </li>
              <li className="footerContactItem">
                <span className="footerContactIcon">🏁</span>
                <span>Near DIT University, Salan Gaon, Bhagwant Pur</span>
              </li>
              <li className="footerContactItem">
                <span className="footerContactIcon">📞</span>
                <a href="tel:01354316767">0135 431 6767</a>
              </li>
              <li className="footerContactItem">
                <span className="footerContactIcon">✉️</span>
                <a href="mailto:Info@ojasspace.com">Info@ojasspace.com</a>
              </li>
              <li className="footerContactItem">
                <span className="footerContactIcon">🕒</span>
                <span>24/7 Live Command Operations</span>
              </li>
            </ul>
          </div>
          <div>
            <h4>FOLLOW US</h4>
            <div className="social">
              <button aria-label="LinkedIn">in</button>
              <button aria-label="X">𝕏</button>
              <button aria-label="Instagram">◎</button>
            </div>
          </div>
        </div>

        {/* BOTTOM LEGAL & META BAR */}
        <div className="footerBottom">
          <div>
            © 2026 MILU AI DRONE PORT. ALL RIGHTS RESERVED.
            (v8.1.0-ENTERPRISE)
          </div>
          <div className="legalLinks">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cookie Policy</a>
            <a href="#">Sitemap</a>
          </div>
          <div className="madeInIndia">ENGINEERED & MADE IN INDIA 🇮🇳</div>
        </div>
      </footer>

      {/* MOBILE FOOTER */}
      <div className="mobileOnly">
        <MobileFooter />
      </div>
    </>
  );
}

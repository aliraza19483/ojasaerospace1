import React, { useEffect, useState } from "react";
import { Home } from "../pages/Home";
import { SectorsPage } from "../pages/SectorsPage";
import { ServicesPage } from "../pages/ServicesPage";
import { ServicePage } from "../pages/ServicePage";
import { TechnologyPage } from "../pages/TechnologyPage";
import { MiluPage } from "../pages/MiluPage";
import { InfrastructurePage } from "../pages/InfrastructurePage";
import { NetworkPage } from "../pages/NetworkPage";
import { PartnersPage } from "../pages/PartnersPage";
import { NewsPage } from "../pages/NewsPage";
import { TeamPage } from "../pages/TeamPage";
import { CareersPage } from "../pages/CareersPage";
import { AboutPage } from "../pages/AboutPage";
import { ContactPage } from "../pages/ContactPage";
import { serviceGroups } from "../constants/services";
import { servicePath } from "../utils/navigation";

export function Router() {
  const [path, setPath] = useState(location.pathname);

  useEffect(() => {
    const f = () => setPath(location.pathname);
    addEventListener("popstate", f);
    return () => removeEventListener("popstate", f);
  }, []);

  if (path === "/" || path === "/home") return <Home />;
  if (path === "/sectors" || path === "/solutions" || path.startsWith("/solutions/"))
    return <SectorsPage />;
  if (path === "/services") return <ServicesPage />;
  if (path === "/technology") return <TechnologyPage />;
  if (path === "/milu-ai") return <MiluPage />;
  if (path === "/milu-ai-network") return <InfrastructurePage />;
  if (path === "/network") return <NetworkPage />;
  if (path === "/partners") return <PartnersPage />;
  if (path === "/news") return <NewsPage />;
  if (path === "/team") return <TeamPage />;
  if (path === "/careers") return <CareersPage />;
  if (path === "/about") return <AboutPage />;
  if (path === "/contact") return <ContactPage />;

  const serviceName = serviceGroups
    .flatMap((g) => g.items)
    .find((x) => servicePath(x) === path);
  if (serviceName) return <ServicePage name={serviceName} />;

  const serviceAlias: Record<string, string> = {
    "/services/surveillance-and-reconnaissance":
      "Surveillance & Reconnaissance",
  };
  if (serviceAlias[path]) return <ServicePage name={serviceAlias[path]} />;

  return <Home />;
}

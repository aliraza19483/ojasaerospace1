// Single source of truth for "should we animate?".
// Priority: URL override (?motion=full | ?motion=reduced, remembered) -> OS setting.
// The result is mirrored on <html data-motion="full|reduced"> so CSS and JS agree.
const query = window.matchMedia("(prefers-reduced-motion: reduce)");
const KEY = "ojas-motion";
const listeners = new Set<() => void>();

function readOverride(): "full" | "reduced" | null {
  try {
    const fromUrl = new URLSearchParams(window.location.search).get("motion");
    if (fromUrl === "full" || fromUrl === "reduced") localStorage.setItem(KEY, fromUrl);
    if (fromUrl === "auto") localStorage.removeItem(KEY);
    const saved = localStorage.getItem(KEY);
    return saved === "full" || saved === "reduced" ? saved : null;
  } catch {
    return null;
  }
}

export function isMotionReduced(): boolean {
  const override = readOverride();
  return override ? override === "reduced" : query.matches;
}

function apply() {
  document.documentElement.dataset.motion = isMotionReduced() ? "reduced" : "full";
  listeners.forEach((fn) => fn());
}

export function onMotionChange(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

apply();
query.addEventListener("change", apply);

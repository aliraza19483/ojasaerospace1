# OJAS Aerospace — V10

V10 refactors the V9 visual baseline around the finalized OJAS information architecture.

## Main routes
- `/`
- `/sectors`
- `/solutions`
- `/services`
- `/technology`
- `/milu-ai-network` — Infrastructure / MILU AI Network
- `/milu-ai`
- `/network`
- `/partners`
- `/news`
- `/team`
- `/careers`
- `/about`
- `/contact`

Solution and service detail routes are generated from the data in `src/App.tsx`.

## Content architecture
Content is data-driven in the main application file so categories, services, technology items, news, team and careers can be moved into a CMS/API later without changing the visual components.

News & Media is seeded with 3 entries for each filter: News, Field Stories, Media, Technology and Events.

Team and Careers contain clearly marked placeholders rather than invented real people or job openings.

## Run locally
```bash
npm install
npm run dev
```

Build:
```bash
npm run build
```

## Motion setting (added)
Animations (hero video, satellite drift, rocket launch, orbit) follow the OS
"reduce motion" setting. To force them on while developing, open
`/?motion=full` (remembered in localStorage); `?motion=reduced` forces reduced
mode and `?motion=auto` goes back to the OS setting. Logic lives in `src/motion.ts`.
